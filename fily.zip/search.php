<?php
$nonav=$nohead='';
require'config.php';
	header('content-type: application/json');

if(!isset($_GET['query'])){
	echo json_encode([]);
	exit();
}

$users = $db->prepare("SELECT id,username FROM users WHERE username LIKE ? ");
$need=$_GET['query'].'%';
$users->execute(array($need));
echo json_encode($users->fetchAll());
