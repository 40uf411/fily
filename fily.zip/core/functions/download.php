<?php
$nohead='';
$nonav='';
require '../../config.php';

    if (!isset($_GET['id']) || $_GET['id']=='') {
        header('location:index.php');
    }
    $id=intval($_GET['id']);
    $file=getInfo('files','WHERE id = '.$id);
    $dwn=$file['0']['downloads']+1;

	$stmt= $db->prepare("UPDATE files SET downloads = ? WHERE `files`.`id` = ?");

	$stmt->execute(array($dwn,$id));

	header('location:http://127.0.0.1/fily/data/upload/'.$file['0']['unique_name']);