<?php
$nohead='';
$nonav='';
require '../../config.php';

if ($_SERVER['REQUEST_METHOD']=='POST' && !isset( $_SESSION['username']) ) {

			$stmt= $db->prepare("SELECT username,password,id,active FROM users WHERE username = ? LIMIT 1");
			$stmt->execute(array($_POST['username']));
			$con = $stmt->fetch();

			if ($stmt->rowCount()==0 || password_verify($_POST['password'],$con['password'])==0) {
				header('location:'.$_SERVER['HTTP_REFERER']);
			}elseif ($con['active']==0) {
				header('location:../../blocked-user.php');
				die();
			}else{

			$_SESSION['username']=$_POST['username'];
			$_SESSION['id']=$con['id'];
			$stmt=$db->prepare("UPDATE `users` SET `lastseen` = now() WHERE `users`.`username` = ?");
			$stmt->execute(array($_SESSION['username']));

				$stmt= $db->prepare("SELECT active FROM users WHERE username =? ");
				$stmt->execute(array($_SESSION['username']));
				if ($stmt->fetch()!=0) {
					$stmt=$db->prepare("UPDATE `users` SET `active` = 1 WHERE `users`.`username` = ?");
					$stmt->execute(array($_SESSION['username']));					
				}

			if (isset($_POST['remember-me'])) {
				setcookie('username',$_SESSION['username'],time()+3600*24*7,'/',null,null,TRUE);	
				setcookie('user-id',$_SESSION['id'],time()+3600*24*7,'/',null,null,TRUE);
			}
			header('location:'.$_SERVER['HTTP_REFERER']);
			exit();

			}

}
