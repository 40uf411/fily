<?php
$nohead="";
$nonav='';
require '../../config.php';
/*
** set the user offline
*/
$stmt=$db->prepare("UPDATE `users` SET `active` = 2 WHERE `users`.`username` = ?");
$stmt->execute(array($_SESSION['username']));
/*
**stop the session
*/
session_start();
session_unset();
session_destroy();
/*
**destroy the usernae,user-id if it exists
*/
if (isset($_COOKIE['username'])) {
	setcookie('username','',time()-3600,'/');
	setcookie('user-id','',time()-3600,'/');
}
header('location:'.$_SERVER['HTTP_REFERER']);
?>