<?php

    $step=(isset($_GET['step']) and $_GET['step']!='')? $_GET['step'] :'1';
     
  ?>
  <div class="container" style="margin-top: 80px">
      <div class="margin20 padding40 block-shadow-impact bd-darkCobalt bg-white " style="border:1px solid;">
      <?php
      if ($step==1){
          if (isset($_SESSION['id'])) {
              header("location:index.php");
            }
      ?>
      <form action="?page=signin&step=2" method="POST">
          <h1>Creat new account.</h1>
          <h3>Username:</h3>
          <div class="input-control text">
            <input type="text" name="username" placeholder="Input you username...">
          </div><br>
          <h3>Email:</h3>
          <div class="input-control text">
            <input type="text" name="email" placeholder="Input you email...">
          </div>
          <h3>Password:</h3>
          <div class="input-control text">
            <input type="password" name="password" placeholder="Input you password...">
          </div><br>
          <h3>Confirm the password:</h3>
          <div class="input-control text">
            <input type="password" name="con_pass" placeholder="Reput you password...">
          </div><br>
          <h3>Gender:</h3>
          <div class="input-control select">
          <select name="gender">
              <option value="male">male</option>
              <option value="female">female</option>
          </select>
      </div><br>
          <h3>Birthday:</h3>
          <div class="input-control text" data-role="datepicker" data-scheme="navy">
              <input type="text" name="birthday" placeholder="Input you Birthday...">
              <button class="button"><span class="mif-calendar"></span></button>
          </div>
          <div class="cell place-right">
                <a href="index.php" class="margin20 button danger block-shadow-danger text-shadow">Cancel</a>
                <a><input type="submit" value="sign in" class="margin20 button primary block-shadow-primary text-shadow"></a>
          </div>

      </form>
      <?php
      }elseif ($step==2) {
          if ($_SERVER['REQUEST_METHOD']=='POST') {
                if (isset($_SESSION['id'])) {
                  header("location:index.php");
                }
                
                if (!isset($_POST['username']) && $_POST['username']=='') {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (!isset($_POST['email']) && $_POST['email']=='') {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (!isset($_POST['password']) && $_POST['password']=='') {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (!isset($_POST['con_pass']) && $_POST['con_pass']=='') {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (!isset($_POST['gender']) && in_array($_POST['gender'],['male','female'])) {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (!isset($_POST['birthday']) && $_POST['birthday']=='') {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (!filter_var( $_POST['email'], FILTER_VALIDATE_EMAIL) ) {header('location:'.$_SERVER['HTTP_REFERER']);}
                if ($_POST['password']!==$_POST['con_pass']) {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (explode('.', $_POST['birthday'])[0]>date('Y') &&
                    explode('.', $_POST['birthday'])[0]<1960 &&
                    explode('.', $_POST['birthday'])[1]>12 &&
                    explode('.', $_POST['birthday'])[1]<=0  &&
                    explode('.', $_POST['birthday'])[2]<=0 && 
                    explode('.', $_POST['birthday'])[2]>31
                    ) {echo "string";}
                if ( strlen($_POST['username'])<4 || strlen($_POST['username'])>16) {header('location:'.$_SERVER['HTTP_REFERER']);}
                if ( strlen($_POST['password'])<8 || strlen($_POST['password'])>50) {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (checkExist('users',$_POST['username'],'username')) {header('location:'.$_SERVER['HTTP_REFERER']);}
                if (checkExist('users',$_POST['email'],'email')) {header('location:'.$_SERVER['HTTP_REFERER']);}

                $stmt=$db->prepare("INSERT INTO `users` (`username`, `password`, `gender`, `email`, `birthday`, `joinday`,`profile_img`) 
                                                 VALUES (?,?,?,?,?,now(),?)");
                $birthday=explode('.', $_POST['birthday'])[0].explode('.', $_POST['birthday'])[1].explode('.', $_POST['birthday'])[2];
                
                $pp=($_POST['gender']=='male')? 'data/pro-img/avatars/man.png': 'data/pro-img/avatars/woman.png';

                $stmt->execute( array( $_POST['username'],password_hash($_POST['password'],PASSWORD_DEFAULT,['cost'=>12]),$_POST['gender'],$_POST['email'],$birthday ,$pp) );
                $_SESSION['username']=$_POST['username'];
                echo $_SESSION['id']=getInfo('users','WHERE username = "'.$_SESSION['username'].'"')['0']['id'];
                ?>
                <div class="bg-emerald fg-white padding20 block-shadow-success" style="margin-bottom: 25px;">
                    <strong class="text-shadow" style="font-size: 1.3em">Done!</strong> your account has been created and set successfully
                </div>
                Do you want to
                <a href="?page=profile" class="button link">view your profile</a>
                or  
                <a href="?page=signin&step=3" class="button primary" style="margin-left:15px">finish your profile</a>
                <?php
          }else{
            echo "Error";
          }
      }elseif ($step==3) {
        ?>
        <div class="align-center">
           <h1>Upload your profile picture</h1>
            <div class=" bd-grayLight" style=" z-index: 1;position: relative;left: 35%; padding: 5px; width: 250px; height: 250px; background-color: #fff; border: 1px solid; border-radius: 50%;">              
                <img class="profile-pg-img" src="/fily/<?php echo getInfo('users','WHERE id = '.$_SESSION['id'])['0']['profile_img'] ?>">    
            </div>           
            <form action="/fily/core/base/update-profile.php?update=profile" method="post" enctype="multipart/form-data">
                <div class="input-control file" data-role="input" style="width: 50%">
                <input type="file" name="profile">
                    <button class="button"><span class="mif-folder"></span></button>
                </div>
                <br>
                <input class="button" type="submit" name="" value="update">
            </form> 
        </div>
        <hr><br>
        <div class="padding20">
        <h1>Other infos.</h1><br>
        <form action="?page=signin&step=4" method="post">
            
           <h3>Full name</h3>
            <div class="input-control text ">
                <input type="text" name="fullName" placeholder="Input you username...">
            </div>
            <h3>Bio</h3>
            <div class="input-control textarea" data-role="input" data-text-auto-resize="true" >
                <textarea name="bio" placeholder="Input your bio" ></textarea>
            </div>
            <h3>Favorit quote</h3>
            <div class="bd-gray" style="border:1px solid;padding:15px; padding-top:5px;padding-bottom: 5px;width: 40% ">
                <div class="input-control textarea"  data-role="input" data-text-auto-resize="true" >
                    <textarea name="fq_0" placeholder="Input your favorit quote"></textarea>
                </div>
                <h4>who said that?</h4>
                <div class="input-control text">
                    <input name="fq_1" type="text" placeholder="Input who said it" value="">
                </div>
                <h4>The source:</h4>
                <div class="input-control text">
                    <input name="fq_2" type="text" placeholder="Input the source" value="">
                </div>
            </div>
            <input class="button primary" type="submit" value="update" style="margin-top: 10px">
        </form> 
        </div>
        <?php
      }elseif ($step==4) {
          if ($_SERVER['REQUEST_METHOD']=='POST') {

                $stmt=$db->prepare("UPDATE users SET fullName = ?,  bio = ?,  fav_quote = ? WHERE `users`.`id` = ?");
                $fav_quote=$_POST['fq_0'].'%'.$_POST['fq_1'].'%'.$_POST['fq_2'].'%';
                $stmt->execute(array($_POST['fullName'],$_POST['bio'],$fav_quote,$_SESSION['id']));
                ?>
                <div class="bg-emerald fg-white padding20 block-shadow-success" style="margin-bottom: 25px;">
                    <strong class="text-shadow" style="font-size: 1.3em">Congratulations!</strong> everything is done now.
                </div>
                <a href="?page=profile" class="button success shadow">Show me my profile</a>
                <?php

          }else{
            header("location:index.php?page=profile");
          }
      }

      ?>
      </div>
  </div>
  <?php  