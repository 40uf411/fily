<?php
session_start();

if (!isset($_SESSION['id'])) {
	header('location:'.$_SERVER['HTTP_REFERER']);
}

if (isset($_FILES['file'])) {
	$file=$_FILES['file'];

	/********************/
	$file['ext']=explode('.', $file['name']);
	$file['ext']=strtolower(end($file['ext']));
	$file['cat_id']=$_POST['cat_id'];
	$file['user_id']=$_SESSION['id'] ;
	$file['description']='';
	$allowed=array('ae','ai','au','avi','br','css','csv','dbf','doc','docx','dw','exe','fw','fla','fi','html','id','iso','js','jpg','json','mp3','mp4','pdf','ps','png','ppt','pi','pr','psd','rtf'.'svg','txt','xls','xml','zip');

	if (in_array($file['ext'], $allowed) && $file['error']==0) {
		echo "2";
		date_default_timezone_set('Europe/london');
		 $file['unique_name']=uniqid(date('ymdhis').'-',false).'.'.$file['ext'];
		 $file['destination']='../../data/upload/'.$file['unique_name'];

		 if (isset($_POST['name']) && isset($_POST['description'])) {
		 	$file['name']=$_POST['name'];
		 	$file['description']=$_POST['description'];
		 }

		 if (move_uploaded_file($file['tmp_name'], $file['destination'])) {
		 	$db = new PDO("mysql:host=localhost;dbname=fily",'root','');
		 	$stmt=$db->prepare("INSERT INTO `files` (`id`, `unique_name`, `name`, `description`, `destination`, `type`, `extension`, `size`, `add_date`, `cat_id`, `user_id`) 
		 									 VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, now(), ?,?)");
		 	$stmt->execute(array($file['unique_name'],$file['name'],$file['description'],$file['destination'],$file['type'],$file['ext'],$file['size'],$file['cat_id'],$file['user_id']));
		 		$stmt= $db->prepare("SELECT id FROM files ORDER BY add_date DESC limit 1 ");
				$stmt->execute();
		 	$id=$stmt->fetch();
		 	header('location:'.$_SERVER['HTTP_REFERER']);		 
		 }else{
			echo "3";
			header('location:'.$_SERVER['HTTP_REFERER']);
		}		

	}else{
		echo "3";
		header('location:'.$_SERVER['HTTP_REFERER']);
	}



}

?>