<?php
/*
**function to check if the user really existes in the db
*/
function checkUser($username,$password)
{
	global $db;
	$stmt= $db->prepare("SELECT username,password,active FROM users WHERE username = ? LIMIT 1");
	$stmt->execute(array($username));
	$con = $stmt->fetch();
	if ($stmt->rowCount()==0) {
		return; 'wrong-username';
	}elseif (password_verify($password,$con['password'])==0) {
		return; 'wrong-password';
	}elseif ($con['active']==0) {
		return; 'blocked-user';
	}else{
		return; 'legal-user';
	}
}
/*
**function to get data from db
*/
function getInfo($where,$op=NUll)
{
	global $db;
	$stmt= $db->prepare("SELECT * FROM $where $op ");
	$stmt->execute();
	return $stmt->fetchAll();
}
/*
**function to get the profile picture of a user
*/
function getProImg($username)
{
	global $db;
	$stmt= $db->prepare("SELECT profile_img FROM users where username = ? ");
	$stmt->execute(array($username));
	return $stmt->fetch();
}
/*
**function to check the existens of something in the db
*/
function checkExist($haystack,$needle,$type='id')
{
	global $db;
	$stmt= $db->prepare("SELECT id FROM $haystack WHERE ".$type."= ? ");
	$stmt->execute(array($needle));
	return ($stmt->rowCount()>0)? true:false;
}
/*
**function to check if the user is an admin
*/
function isadmin($id)
{
	global $db;
	$stmt= $db->prepare("SELECT id FROM users WHERE id= ? and group_id = 1");
	$stmt->execute(array($id));
	return ($stmt->rowCount()>0)? true:false;	
}
/*
**function to convert an array to string
*/
function aryToStr($array,$between='&',$first=false)
{
	$string=NULL;

	foreach ($array as $key => $value) {
		if (!$first) {
		$string=$key.'='.$value;
		$first=true;
		}else
			$string=$string.$between.$key.'='.$value;
	}
	return $string;
}
/*
** function return the count of items in a table in the db
*/
function getCount($where)
{
	global $db;
	$stmt= $db->prepare("SELECT id FROM $where ");
	$stmt->execute();
	return $stmt->rowCount();	
}
/*
**function to show a colored point based on the statu of a user
*/
function statuPoint($id)
{
	global $db;
	$user=getInfo('users','WHERE id = '.$id);
	    if ($user['0']['active']=='1') {
        echo "<span class='bg-lightGreen pro-stt'></span>";
    }elseif ($user['0']['active']=='2') {
        echo "<span class='bg-amber pro-stt'></span>";
    }elseif ($user['0']['active']=='0') {
        echo "<span class='bg-red pro-stt'></span>";
    }
}
/*
**function to redirect user to some page.
*/
function go($time=3,$to='index.php')
{
	header("refresh:$time;url:$to");
}