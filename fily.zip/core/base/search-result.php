?>
<div class="container page-content">


<?php

    $option=(isset($_GET['option']) && in_array($_GET['option'],array('files','users','categories')))? $_GET['option']: 'files';
    
    if (!isset($_GET['name']) || $_GET['name']=='') {
        header('location:'.$_SERVER['HTTP_REFERER']);
        die();
    }

    $name=$_GET['name'];

    if ($option=='files') {

        $show=(isset($_GET['show']))? ' LIMIT '.$_GET['show']: ' LIMIT '.'10' ;
        $cat_id=(isset($_GET['cat_id']) && $_GET['cat_id']!='all' )?  ' AND cat_id = '.$_GET['cat_id']:Null;
        $extension=(isset($_GET['extension']) && $_GET['extension']!='all')?  " AND extension = '".$_GET['extension']."'":Null;
        $size=(isset($_GET['size']) && $_GET['size']!='all')?  ' AND size <'.$_GET['size']:Null;
        
        $query="WHERE name LIKE '%".$name."%'".$cat_id.$extension.$size.' ORDER BY add_date DESC'.$show;

        echo '  
        <div class="grid">
        <div class="row cells2">
            <div class="cell">
                <h3>Do another search:</h3>
            </div>
            <div class="cell">
            <form action="index.php?page=search-result" method="GET">
                <input type="hidden" name="page" value="search-result">
                <input type="hidden" name="option" value="files">
                <div class="input-control text full-size" data-role="input">
                    <input style="padding-right: 58px;" type="text" placeholder="Type to search" name="name">
                <input type="hidden" name="cat_id" value="'; echo (isset($_GET['cat_id']) && $_GET['cat_id']!='all' )? $_GET['cat_id']:'all'; echo'">
                <input type="hidden" name="extension" value="'; echo (isset($_GET['extension']) && $_GET['extension']!='all')?  $_GET['extension']:'all'; echo'">
                <input type="hidden" name="size" value="'; echo (isset($_GET['size']) && $_GET['size']!='all')?  $_GET['size']:'all'; echo'">
                    <button class="button"><span class="mif-search"></span></button>
                    
                </div>            
            </form>              
            </div>
        </div>
        </div><br>';

        if (empty(getInfo('files',$query))) {
            echo '  <div style="margin-bottom:100px;margin-top:100px;">
                        <h1 class="fg-grayLight" ><b>No result found</b> for This search.</h1>
                        <a href="'.$_SERVER['HTTP_REFERER'].'" class="button link" style="font-size:20px">Go back!</a>
                    </div>
                ';
        }else{
        echo '
        <h1>Search result:</h1>
        <div class="split-button">
            <button class="button">show</button>
            <button class="split dropdown-toggle"></button>
            <ul class="split-content d-menu" data-role="dropdown">
                <li><a href="?'.aryToStr($_GET).'&show=5">5</a></li>
                <li><a href="?'.aryToStr($_GET).'&show=10">25</a></li>
                <li><a href="?'.aryToStr($_GET).'&show=100">100</a></li>
            </ul>
        </div>
        <div class="grid">';
        foreach (getInfo('files',$query) as $file) {

            $user=getInfo('users','WHERE id='.$file['user_id']);
          echo '                
          <div class="srch-rslt-itm bd-darkCobalt shadow">';
                                            if (isset($_SESSION['id'])) {

                        echo'
                        <div class="dropdown-button place-right">
                            <button class="split dropdown-toggle bg-focus-darkCyan "></button>
                            <ul class="split-content d-menu place-right navy shadow" data-role="dropdown" >';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$file['user_id']) {

                        echo   '<li><a href="index.php?page=file&do=edit&id='.$file['id'].'">Edit File</a></li>';
                        }
                        if ($_SESSION['id']!=$file['user_id']) {
                        echo'   <li><a href="index.php?page=file&do=report&id='.$file['id'].'">Report file</a></li>';
                        }
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' && $_SESSION['id']!=$file['user_id']) {
                        echo   '<li><a href="#">Send an Alert to '.$user[0]['username'].'</a></li>';
                        }
                        echo   '<li class="divider"></li>';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$file['user_id']) {
                        echo   '<li><a href="index.php?page=file&do=remove&id='.$file['id'].'" class="fg-crimson bg-hover-crimson fg-hover-white"> Remove File</a></li>';
                        }
                        if ( $file['user_id']!=1 && getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' ) {        
                        echo   '<li><a href="#" class="bg-darkRed bg-hover-crimson"><span class="mif-blocked"></span> Block '.$user[0]['username'].'</a></li>';
                        }
                        echo   '</ul>
                        </div>';
                        }
                        echo'          

                    <h2 style="font-weight: normal;">'.$file['name'].'</h2>
                    <div class="row cells4">
                        <div class="cell align-justify">
                            <h4>About:</h4>
                            <p>'.$file['description'].'</p>
                        </div>
                        <div class="cell">
                            <h4>Added At:</h4>
                            <p>'.$file['add_date'].'</p>
                        </div>
                        <div class="cell">
                            <h4>Added by:</h4>
                            <p><a href="index.php?page=profile&id='.$file['user_id'].'">'; echo $user[0]['username'] ; echo '</a></p>
                        </div>
                        <div class="cell">
                            <a href="index.php?page=perview&id='.$file['id'].'" class="button link">See more</a>
                            <a class="button " href="core/functions/download.php?id='.$file['id'].'" >Download ( ';
                        if ($file['size']>=1073741824){
                            echo intval($file['size']/1073741824);
                            echo 'GB';
                        }elseif ($file['size']>=1048576) {
                            echo intval($file['size']/1048576);
                            echo 'MB';
                        }elseif ($file['size']>=1024) {
                            echo intval($file['size']/1024);
                            echo 'kB';
                        }else{
                            echo $file['size'];
                            echo 'B';
                        }
                                echo ' )</a>
                        </div>
                    </div>
                </div>';  
        }}
        echo "</div>";

    }elseif ($option=='users') {
        
        echo '  
        <div class="grid">
        <div class="row cells2">
            <div class="cell">
                <h3>Do another search:</h3>
            </div>
            <div class="cell">
            <form action="index.php?page=search-result" method="GET">
                <input type="hidden" name="page" value="search-result">
                <input type="hidden" name="option" value="users">
                <div class="input-control text full-size" data-role="input">
                    <input style="padding-right: 58px;" type="text" placeholder="Type to search" name="name">
                    <button class="button"><span class="mif-search"></span></button>
                    
                </div>            
            </form>              
            </div>
        </div>
        </div><br> 
        

        <h1>Search result:</h1>
            ';
        $query='WHERE username LIKE "'.$name.'%" OR email = "'.$name.'" OR fullName = "%'.$name.'%" AND active!=0 ORDER BY joinday';
        if (empty(getInfo('users',$query))) {
            echo '  <div style="margin-bottom:100px;margin-top:100px;">
                        <h1 class="fg-grayLight" ><b>No result found</b> for This search.</h1>
                        <a href="'.$_SERVER['HTTP_REFERER'].'" class="button link" style="font-size:20px">Go back!</a>
                    </div>
                ';
        }else{

            foreach (getInfo('users',$query) as $user) {
                echo '      
                <div class="grid">                
                    <div class="srch-rslt-itm bd-darkCobalt shadow">
                        <div class="row cells4">
                            <div class="cell">
                                <img class="big-pro-img shadow" src="'.$user['profile_img'].'">
                            </div>
                            <div class="cell">
                                <h1><b>'.$user['username'].'</b></h1>
                                <h3>Bio:</h3>
                                <p>'.$user['bio'].'</p>
                            </div>
                            <div class="cell">
                                <h2>birthday:</h2>
                                <p>'.$user['birthday'].'</p>
                                <h2>Shared files:</h2>
                                <p>20</p>
                            </div>
                            <div class="cell">
                                <a class="button primary" href="">Add friend</a>
                                <a class="button link" href="index.php?page=profile&id='.$user['id'].'">View profile</a>
                            </div>                                      
                        </div>
                    </div>
                </div>'; 
             }

        }  

    }elseif ($option=='categories') {
        
        echo '  
        <div class="grid">
        <div class="row cells2">
            <div class="cell">
                <h3>Do another search:</h3>
            </div>
            <div class="cell">
            <form action="index.php?page=search-result" method="GET">
                <input type="hidden" name="page" value="search-result">
                <input type="hidden" name="option" value="categories">
                <div class="input-control text full-size" data-role="input">
                    <input style="padding-right: 58px;" type="text" placeholder="Type to search" name="name">
                    <button class="button"><span class="mif-search"></span></button>
                    
                </div>            
            </form>              
            </div>
        </div>
        </div><br> 
        

        <h1>Search result:</h1>
            ';
        $query='WHERE name LIKE "%'.$name.'%" ORDER BY name';
        if (empty(getInfo('categories',$query))) {
            echo '  <div style="margin-bottom:100px;margin-top:100px;">
                        <h1 class="fg-grayLight" ><b>No result found</b> for This search.</h1>
                        <a href="'.$_SERVER['HTTP_REFERER'].'" class="button link" style="font-size:20px">Go back!</a>
                    </div>
                ';
        }else{

            foreach (getInfo('categories',$query) as $cat) {
                echo '      
                <div class="grid">                
                    <div class="srch-rslt-itm bd-darkCobalt shadow">

                        <div class="row cells3">
                            <div class="cell">
                                <h1><b>'.$cat['name'].'</b></h1>
                            </div>
                            <div class="cell">
                                <h2>Description:</h2>
                                <p>'.$cat['description'].'</p>
                                                    </div>
                            <div class="cell">
                                <a class="button fg-white bg-darkCobalt bg-hover-darkBlue bg-active-darkIndigo bd-darkBlue" href="upload.php?cat_id='.$cat['id'].'">Upload new file</a>
                                <a class="button link" href="categories.php?id='.$cat['id'].'">Browse category -></a>
                            </div>  

                        </div>
                    </div>
                </div>'; 
             } 

        }        
    }

