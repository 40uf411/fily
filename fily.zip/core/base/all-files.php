
<div class="container page-content">

<?php
            $category=(isset($_GET['category']))? 'AND cat_id = '.intval($_GET['category']):null;
            $order=(isset($_GET['order']) && in_array($_GET['order'], array('name','size','add_date','last_edit','downloads')))? $_GET['order'] :'last_edit';
             $order_way='ASC';
            if (!isset($_GET['ow']) &&  ($order=='add_date' || $order=='last_edit' || $order=='downloads') ) {
             $order_way='DESC';
            }

            if(isset($_GET['ow']) && in_array($_GET['ow'], array('ASC','DESC'))){
            $order_way=$_GET['ow'];
            } 



            if (isset($_GET['need']) && in_array($_GET['need'] ,array('audio','video','book','picture','compressed','all')) ) {
                $need=$_GET['need'];
            }else{
                $need='all';
            }
            if ($need=='all') {
                $need=NULL;
            }elseif ($need=='audio') {
                $need=' AND extension = "mp3" ';
            }elseif ($need=='video') {
                $need=' AND extension = "mp4"';
            }elseif ($need=='book') {
                $need=' AND (extension = "pdf" OR extension = "doc")';
            }elseif ($need=='picture') {
                $need=' AND (extension = "jpg" OR extension = "png")';
            }elseif ($need=='compressed') {
                $need=' AND (extension = "zip" OR extension = "rar")';
            }

    echo '

    <div data-role="dialog,draggable" id="dialog"  class="padding20 dialog bd-darkCobalt"  data-close-button="true" data-overlay="true" data-overlay-click-close="true" data-overlay-color="op-dark" style="width: auto; height: auto; visibility: visible; left: 281px; top: 99.5px; border:1px solid; box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.4); z-index:1000; ">

            <h1>Upload new file</h1>
            <form action="core/functions/f-upload.php" method="post" enctype="multipart/form-data">
                <h3>Select th file</h3>
                <div class="input-control file" data-role="input">
                    <input type="file" name="file">
                    <button class="button"><span class="mif-folder"></span></button>
                </div>
                <div class="input-control select">
                    <select name="cat_id">';
                    foreach (getInfo('categories') as $cat) {
                        echo '<option value="'.$cat['id'].'">'.$cat['name'].'</option>';
                    }
                    echo'
                    </select>
                </div>
                <input type="submit" value="upload">
            </form>
            <br><br>
            <div class="padding10 bg-orange fg-white">
                <p><span class="mif-info mif-3x"></span> File informations will be set automatically or you can go to the upload page and set all the informations manually</p>
                <a href="" class="button warning  block-shadow ">Go to upload page!</a>
            </div>

        <span class="dialog-close-button"></span>
        
    </div>
            <h1 style="font-size:60px; ">Browser all the files:</h1>
            <div class="split-button" style="margin-bottom:35px; margin-right:5px;">
                ';
                if(isset($_SESSION['id'])){
                ?><button onclick="metroDialog.open('#dialog')"  class="button primary text-shadow block-shadow-primary" style="margin-right:5px;"><span class="mif-upload"></span> upload new File</button><?php
                }
                 echo '
            </div>
            <div class="split-button" style="margin-bottom:35px;">
                <button class="button dropdown-toggle ">Sort by</button>
                <button class="split  dropdown-toggle "></button>
                <ul class="split-content d-menu  place-right" data-role="dropdown">
                    <li><a href="?order=name">';echo ($order=='name')? '<span class="mif-checkmark"></span>':''; echo ' Name</a></li>
                    <li><a href="?order=size">';echo ($order=='size')? '<span class="mif-checkmark"></span>':''; echo ' Size</a></li>
                    <li><a href="?order=add_date">';echo ($order=='add_date')? '<span class="mif-checkmark"></span>':''; echo ' Add date</a></li>
                    <li><a href="?order=last_edit">';echo ($order=='last_edit')? '<span class="mif-checkmark"></span>':''; echo ' Last Edite</a></li>
                    <li><a href="?order=downloads">';echo ($order=='downloads')? '<span class="mif-checkmark"></span>':''; echo ' Download times</a></li>
                </ul>
                <a class="button " style="margin-left:5px;"';
                echo($order_way=='DESC')? 'href="?order='.$order.'&ow=ASC"> ASC': 'href="?order='.$order.'&ow=DESC"> DESC' ; 
                echo '</a>
            </div>
            <div class="split-button" style="margin-bottom:35px;">
                <button class="button dropdown-toggle ">i\'m looking for:</button>
                <button class="split  dropdown-toggle "></button>
                <ul class="split-content d-menu  place-right" data-role="dropdown">
                    <li><a href="?order='.$order.'&ow='.$order_way.'&need=audio">';echo ($need=='audio')? '<span class="mif-checkmark"></span>':''; echo ' Audio file/Music</a></li>
                    <li><a href="?order='.$order.'&ow='.$order_way.'&need=video">';echo ($need=='video')? '<span class="mif-checkmark"></span>':''; echo ' Video file/Cip</a></li>
                    <li><a href="?order='.$order.'&ow='.$order_way.'&need=book">';echo ($need=='book')? '<span class="mif-checkmark"></span>':''; echo ' Book</a></li>
                    <li><a href="?order='.$order.'&ow='.$order_way.'&need=picture">';echo ($need=='picture')? '<span class="mif-checkmark"></span>':''; echo ' Picture/Image</a></li>
                    <li><a href="?order='.$order.'&ow='.$order_way.'&need=compressed">';echo ($need=='compressed')? '<span class="mif-checkmark"></span>':''; echo ' Compressed/zip|rar</a></li>
                    <li><a href="?order='.$order.'&ow='.$order_way.'&need=all">';echo ($need=='all' || $need==null)? '<span class="mif-checkmark"></span>':''; echo ' Not sure!</a></li>

                </ul>
            </div>
    ';


            $stmt=$db->prepare("SELECT files.*,
                        categories.name AS category_name,
                        users.username AS username,
                        users.active AS active,
                        users.group_id AS grade
                        FROM files

                        INNER JOIN
                        categories
                        ON
                        categories.id=files.cat_id
                        INNER JOIN
                        users
                        ON
                        users.id=files.user_id
                        WHERE users.active!=0
                        ".$need." ".$category."
                        ORDER BY ".$order." ".$order_way." "
                        );
            $stmt->execute();
            $files=$stmt->fetchAll();
foreach ($files as $file): 

        echo'<div class="item-container bg-white shadow bd-darkCobalt">
                <div class="grid no-margin-top">
                    <ul class="breadcrumbs ">
                        <li><a href="index.php"><span class="icon mif-home"></span></a></li>
                        <li><a href="index.php?page=profile&id='.$file['user_id'].'"><b>'.$file['username'].'</b></a></li>
                        <li><a href="index.php?category='.$file['cat_id'].'">'.$file['category_name'].'</a></li>
                        <li><a href="?page=perview&id='.$file['id'].'">'.$file['name'].'</a></li>';
                        if (isset($_SESSION['id'])) {

                        echo'
                        <div class="dropdown-button place-right">
                            <button class="split dropdown-toggle bg-focus-darkCyan "></button>
                            <ul class="split-content d-menu place-right navy shadow" data-role="dropdown" >';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$file['user_id']) {

                        echo   '<li><a href="index.php?page=file&do=edit&id='.$file['id'].'">Edit File</a></li>';
                        }
                        if ($_SESSION['id']!=$file['user_id']) {
                        echo'   <li><a href="index.php?page=file&do=report&id='.$file['id'].'">Report file</a></li>';
                        }
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' && $_SESSION['id']!=$file['user_id']) {
                        echo   '<li><a href="#">Send an Alert to '.$file['username'].'</a></li>';
                        }
                        echo   '<li class="divider"></li>';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$file['user_id']) {
                        echo   '<li><a href="index.php?page=file&do=remove&id='.$file['id'].'" class="fg-crimson bg-hover-crimson fg-hover-white"> Remove File</a></li>';
                        }
                        if ( $file['user_id']!=1 && getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' ) {        
                        echo   '<li><a href="?page=users&do=block&id='.$file['user_id'].'" class="bg-darkRed bg-hover-crimson"><span class="mif-blocked"></span> Block '.$file['username'].'</a></li>';
                        }
                        echo   '</ul>
                        </div>';
                        }
                        echo '

                    </ul>
                    <div class="row cells3">
                        <div class="cell2">
                            <div class="';  
                            if($file['extension']=='pdf' || $file['extension']=='fla' || $file['extension']=='flash'){
                                echo "bg-red bd-red";
                            }elseif ($file['extension']=='ai' || $file['extension']=='js' || $file['extension']=='svg' || $file['extension']=='xml') {
                                echo "bg-amber bd-amber";
                            }elseif ($file['extension']=='avi' || $file['extension']=='csv' || $file['extension']=='mp4') {
                                echo "bg-magenta bd-magenta";
                            }elseif ($file['extension']=='css' || $file['extension']=='doc' || $file['extension']=='dwg' || $file['extension']=='psd' || $file['extension']=='rtf') {
                                echo "bg-darkCobalt bd-darkCobalt";
                            }elseif ($file['extension']=='html' || $file['extension']=='ppt') {
                                echo "bg-orange bd-orange";
                            }elseif ($file['extension']=='iso' || $file['extension']=='png' || $file['extension']=='jpg') {
                                echo "bg-green bd-green";
                            }elseif ($file['extension']=='txt' || $file['extension']=='zip' || $file['extension']=='') {
                                echo "bg-grayDarker bd-grayDarker";
                            }elseif ($file['extension']=='exe' || $file['extension']=='mp3' || $file['extension']=='json') {
                                echo "bg-darkViolet bd-darkViolet";
                            }
                            echo ' tile type-img" data-role="tile">
                                <img src="/fily/data/default_types/'.$file['extension'].'.png">
                            </div>                  
                        </div>
                
                        <div class="cell3">
                            <h1 class="leader itm-ttl">';
                            echo (strlen($file['name'])>10)? str_split($file['name'],10)['0'].'...'.$file['extension'] : $file['name'];
                            echo '</h1>
                            <h4>Shared at: '.$file['add_date'].'</h4>
                        </div>
                         <div class=" cells3 place-right" style"margin-right:5px">
                            <div class="cell2" style="margin-right: 10px">';
                            if ($file['extension']=='mp3') {
                                echo '

                                    <div data-role="audio" data-mode="micro">
                                        <audio controls>
                                            <source src="/fily/data/upload/'.$file['unique_name'].'" type="audio/mp3" />
                                        </audio>
                                    </div>
                                ';
                            }
                                echo '<a class="button link" href="?page=perview&id='.$file['id'].'" >See more info</a>
                                <a class="button " href="core/functions/download.php?id='.$file['id'].'" ><i class="mif-download"></i>  Download (';
                        if ($file['size']>=1073741824){
                            echo intval($file['size']/1073741824);
                            echo ' GB';
                        }elseif ($file['size']>=1048576) {
                            echo intval($file['size']/1048576);
                            echo ' MB';
                        }elseif ($file['size']>=1024) {
                            echo intval($file['size']/1024);
                            echo ' kB';
                        }else{
                            echo $file['size'];
                            echo ' B';
                        }
                                echo ')</a>
                            </div>                  
                        </div>
                   </div>
                </div>
            </div>';
    
     endforeach;
