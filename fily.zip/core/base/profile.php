<?php
    if (!isset($_SESSION['id']) && !isset($_GET['id'])) {
                    echo '
            <div class="container">
                <div class="padding60 magin20 bg-darkRed fg-red shadow align-center" style="margin-top:70px; width:100%">
                    <h1>You don\'t have permission to browse this page</h1>
                </div>
            </div>
            ';
            die;
    }
    if (!isset($_GET['id']) || $_GET['id']=='' || intval($_GET['id'])==0)  {
        $id=$_SESSION['id'];
    }elseif (intval($_GET['id'])==0) {
        header('location:index.php');
    }else{
        $id=intval($_GET['id']);
    }

    $do=(isset($_GET['do']) && in_array($_GET['do'], array('show','edit')))? $_GET['do'] :'show';
    if ($do=='show') {
        
    $show_page=(isset($_GET['show_page']) && in_array($_GET['show_page'], array('timeline','about')))? $_GET['show_page'] :'about';
    

    $user=getInfo('users','WHERE id = '.$id);


    ?>
    <div class="profile-content">

        <div class="grid">
            <div class="row cells1 no-margin-bottom">
                
                <div class=" cell wallpaper bd-dark" style='margin-bottom: 0;'>
                <div class="pro_cover" style='background-image: url("<?php echo $user['0']['bg_img'] ?>");'></div>
                    <div class="profile-img-unm" >
                        <div class="profile-frame bd-grayLight">              
                            <img class="profile-pg-img" src="/fily/<?php echo $user['0']['profile_img'] ?>">    
                        </div>
                        <h1 class="profile_username "><?php echo $user['0']['username'] ?>  
                        <?php 
                            statuPoint($user['0']['id']);
                         ?>
                             
                         </h1>                 
                    </div>
                </div>
            </div>
                    <div class="bd-darkCobalt bg-white"  style="padding: 5px; height: 53px;width: 100%;box-shadow: 0 2px 5px 0 rgba(0,0,0,0.28),0 -2px 5px 0 rgba(0,0,0,0.7);margin-bottom:5px;border-bottom: 1px solid;">
                        <div class="container">
                        <?php if (isset($_SESSION['id'])) { ?>
                            <div class="place-right">
                                <a href="?page=profile&do=edit&edit=profile_cover" class="button bd-darkCobalt fg-darkCobalt bg-hover-darkCyan bg-active-darkCobalt fg-active-white"><b>Edit cover and avatar</b></a>
                        <?php } ?>        
                            </div>
                        </div>
                    </div>
            <div class="flex-grid">
                <div class="row cells2">
                    <div class="cell size-p20">
                            <ul class="sidebar2 compact main">
                                <?php if (isset($_SESSION['id']) && $id==$_SESSION['id'] ): ?>
                                  <li class=""><a href="index.php?page=profile&do=edit">Edit profile</a></li>  
                                <?php endif ?>

                                <li class="active"><a href="index.php?page=profile&show_page=timeline&id=<?php echo $user['0']['id'] ?>">Timeline</a></li>
                                <li class=""></li>
                                <li class="active" ><a href="index.php?page=profile&show_page=about&id=<?php echo $user['0']['id'] ?>">About</a></li>
                                <li><a>Username: <?php echo $user['0']['username'] ?></a></li>
                                <li><a>Fullname: <?php echo $user['0']['fullName'] ?></a></li>
                                <li><a>Gender: <?php echo $user['0']['gender'] ; echo($user['0']['gender']=='male')? '<span class="mif-male"></span>':'<span class="mif-female"></span>'; ?> </a></li>

                                <li class="active"><a>Files shared: <span class="tag info"><?php echo getCount('files WHERE user_id = '.$user['0']['id']) ?></span></a></li>
                                <li class=""></li>
                                <li class="active"><a>Last seen: <span class="tag "><?php echo($user['0']['active']=='1')? 'Online': explode(' ', $user['0']['lastseen'])['0'].' '.explode(':',explode(' ', $user['0']['lastseen'])['1'])['0'].':'.explode(':',explode(' ', $user['0']['lastseen'])['1'])['1'];   ?></span> </a></li>

                            </ul>
                    </div>
    <?php
    echo '<div class="cell size-p70">';
    if ($show_page=='about') {
    ?>
                    
                        <div class=" margin20 show-box bd-darkCobalt shadow bg-white">
                            <h1><b>Bio:</b></h1>
                            <p class="align-center"><?php echo $user['0']['bio'] ?></p>
                        </div>
                        <div class=" margin20 show-box bd-darkCobalt shadow bg-white">
                            <h1><b>About:</b></h1>
                            <h3>Fullname:<?php echo $user['0']['fullName'] ?></h3>
                            <h3>Birthday: <?php echo $user['0']['birthday'] ?></h3>
                            <h3>Gender: <?php echo $user['0']['gender'] ?></h3>
                            <h3>Email: <?php echo $user['0']['email'] ?></h3>
                            <h3>joinday: <?php echo $user['0']['joinday'] ?></h3>
                        </div>
                        <div class=" margin20 show-box bd-darkCobalt shadow bg-white">
                            <h1><b>Favorit quote:</b></h1>
                            <blockquote>
                                <p><?php echo explode('%', $user['0']['fav_quote'])['0']; ?></p>
                                <small><?php echo @explode('%', $user['0']['fav_quote'])['1']; ?> <cite title="Source Title"> <?php echo @explode('%', $user['0']['fav_quote'])['2']; ?> </cite></small>
                            </blockquote>
                        </div>
                    </div>
     <?php   
    }else{

    foreach (getInfo('files','WHERE user_id = '.$id.' ORDER BY last_edit DESC') as $itm) {

    ?>

                        <div class="profile-itm  bd-darkCobalt shadow bg-white">
                        <?php 
                        if (isset($_SESSION['id'])) {

                        echo'
                        <div class="dropdown-button place-right">
                            <button class="split dropdown-toggle bg-focus-darkCyan "></button>
                            <ul class="split-content d-menu place-right navy shadow" data-role="dropdown" >';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$itm['user_id']) {

                        echo   '<li><a href="index.php?page=file&do=edit&id='.$itm['id'].'">Edit File</a></li>';
                        }
                        if ($_SESSION['id']!=$itm['user_id']) {
                        echo'   <li><a href="index.php?page=file&do=report&id='.$itm['id'].'">Report file</a></li>';
                        }
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' && $_SESSION['id']!=$itm['user_id']) {
                        echo   '<li><a href="#">Send an Alert to '.$user['0']['username'].'</a></li>';
                        }
                        echo   '<li class="divider"></li>';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$itm['user_id']) {
                        echo   '<li><a href="index.php?page=file&do=remove&id='.$itm['id'].'" class="fg-crimson bg-hover-crimson fg-hover-white"> Remove File</a></li>';
                        }
                        if ( $itm['user_id']!=1 && getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' ) {        
                        echo   '<li><a href="#" class="bg-darkRed bg-hover-crimson"><span class="mif-blocked"></span> Block '.$user['0']['username'].'</a></li>';
                        }
                        echo   '</ul>
                        </div>';
                        }
                         ?>
                            <h2 style="font-weight: normal;"><?php echo $itm['name']; ?></h2>
                            <div class="">
                                <div class="row flex-just-sa">
                                    <div class="cell align-justify auto-size">
                                        <h4>Description:</h4>
                                        <p><?php echo $itm['description']; ?></p>
                                    </div>
                                    <div class="cell auto-size">
                                        <h4>Added At:</h4>
                                        <p><?php echo $itm['add_date']; ?></p>
                                    </div>
                                    <div class="cell auto-size">
                                        <h4>Added by:</h4>
                                        <p><a href=""><?php echo $user['0']['username']; ?></a></p>
                                    </div>
                                    <div class="cell auto-size">
                                        <a href="index.php?page=perview&id=<?php echo $itm['id']; ?>" class="button link">See more</a>
                                        <a class="button " href="core/functions/download.php?id=<?php echo $itm['id']; ?>">Download</a>
                                    </div>
                                </div>                          
                            </div>
                        </div>
    <?php
    }
    }




    ?>

                </div>          
            </div>
        </div>


    <?php
    }else{
        if (!isset($_SESSION['id'])){
            echo '
            <div class="container">
                <div class="padding60 magin20 bg-darkRed fg-red shadow align-center" style="margin-top:70px; width:100%">
                    <h1>You don\'t have permission to browse this page</h1>
                </div>
            </div>
            ';
            die;
        }
        $edit=(isset($_GET['edit']) && in_array($_GET['edit'],array('profile_cover','general','security','details','files','des_del')))? $_GET['edit']: 'general';
        $user=getInfo('users','WHERE id = '.$_SESSION['id']);
        ?>
        <div class="container page-content">
        <div class="profile-edit bd-darkCobalt margin20 padding20 shadow bg-white">
            <div class="grid">
                <div class="row cells12">
                    <div class="cell colspan3 " >
                        <ul class="sidebar2 main">
                            <li <?php echo($edit=='profile_cover')? 'class="active"':''; ?> ><a href="?page=profile&do=edit&edit=profile_cover">Profile and cover picture</a></li>
                            <li <?php echo($edit=='general')? 'class="active"':''; ?> ><a href="?page=profile&do=edit&edit=general">General</a></li>
                            <li <?php echo($edit=='security')? 'class="active"':''; ?>><a href="?page=profile&do=edit&edit=security">Secerity</a></li>
                            <li <?php echo($edit=='details')? 'class="active"':''; ?>><a href="?page=profile&do=edit&edit=details">Details</a></li>
                            <li <?php echo($edit=='files')? 'class="active"':''; ?>><a href="?page=profile&do=edit&edit=files">File manager</a></li>
                            
                            <li <?php echo($edit=='des_del')? 'class="active"':''; ?>><a href="?page=profile&do=edit&edit=des_del">Desactivat or delete account</a></li>

                        </ul>
                    </div>
                    
                    <div class="cell colspan9 padding20 bd-darkCobalt profile-edit-list" >
                    <?php
                    if ($edit=='general') {
                    ?>

        <form action="/fily/core/base/update-profile.php?update=general" method="post" data-role="validator">
            <h3>Username:</h3>
            <div class="input-control text" style="width: 50%">
                <input type="text"  placeholder="Input your new username" name="username" value="<?php echo $user['0']['username']; ?>" data-validate-func="required, minlength" data-validate-arg=",4" data-validate-hint="Username can not be empty or less than 4!" data-validate-hint-position="right" required>
                        <span class="input-state-error mif-warning"></span>
                        <span class="input-state-success mif-checkmark"></span>

            </div>
            <h3>Full name:</h3>
            <div class="input-control text" style="width: 50%">
                <input type="text" placeholder="Input your full name" name="fullName" value="<?php echo $user['0']['fullName']; ?>" data-validate-func="required, minlength" data-validate-arg=",4" data-validate-hint="Full name can not be empty or less than 4!" data-validate-hint-position="right"  required>
                        <span class="input-state-error mif-warning"></span>
                        <span class="input-state-success mif-checkmark"></span>
            </div>
            <h3>Email:</h3>
            <div class="input-control text" style="width: 50%">
                <input type="text" placeholder="Input you text here..." name="email" required value="<?php echo $user['0']['email']; ?>" data-validate-func="required, email" data-validate-hint="Please enter a valid email!" data-validate-hint-position="right">
                        <span class="input-state-error mif-warning"></span>
                        <span class="input-state-success mif-checkmark"></span>

            </div> 
            <br>
            <input class="button" type="submit" name="" value="update">
        </form>
                        <?php
                        }elseif ($edit=='profile_cover') {
                            $user=getInfo('users','WHERE id = '.$_SESSION['id']);
                        ?>
                        <div class="bd-darkCobalt" style="border: 1px solid; margin-bottom: 50px;border-radius: 5px;">

                            <div style="height: 200px; overflow: hidden;">
                                <img src="<?php echo $user['0']['bg_img'] ?>" style="border-radius: 4px;">
                            </div>
                            <div style="height: 30px;width: 100%;box-shadow: 0 -50px 50px 3px rgba(0,0,0,.7),0 2px 5px 0 rgba(0,0,0,0.4);border-radius: 0 0 5px 5px;"></div>
                            <div class="bd-grayLight" style="position: absolute;border:1px solid; ;padding: 3px; width: 130px;height: 130px; top:23%;left:22%;background-color: #fff;border-radius: 50%;">
                                <img src="/fily/<?php echo $user['0']['profile_img'] ?>" style="height: 100%;border-radius: 50%">
                                
                                <h2 class="text-shadow fg-white" style="position: absolute;top: 29%;left: 104%;"><?php echo $user['0']['username']; ?> <span class="bg-lightGreen" style="position: absolute;border-radius: 50%;top: 30%;right: -10%; padding: 4px; height: 5px;width: 3px;"></span></h2>
                                
                            </div>
                        </div>
                        <form action="/fily/core/base/update-profile.php?update=profile" method="post" enctype="multipart/form-data">
                        <h3>Profile picture</h3>
                        <div class="input-control file" data-role="input" style="width: 50%">
                            <input type="file" name="profile">
                            <button class="button"><span class="mif-folder"></span></button>
                        </div>
                            <br>
                            <input class="button" type="submit" name="" value="update">
                        </form>
                        <hr>
                        <form action="/fily/core/base/update-profile.php?update=cover" method="post" enctype="multipart/form-data">
                        <h3>Cover picture</h3>
                        <div class="input-control file" data-role="input" style="width: 50%">
                            <input type="file" name="cover">
                            <button class="button"><span class="mif-folder"></span></button>
                        </div>
                            <br>
                            <input class="button" type="submit" name="" value="update">
                        </form>



                        <?php
                        }if ($edit=='security') {
                        ?>

                        <form action="/fily/core/base/update-profile.php?update=security" method="post" data-role="validator">
                            <h3>Old password:</h3>
                            <div class="input-control password" data-role="input" style="width: 50%">
                                <input name="old_pass" type="password" placeholder="Input your old password" data-validate-func="required, minlength" data-validate-arg=",8" data-validate-hint="password can not be empty or less than 8!" data-validate-hint-position="right"  required>
                                <button class="button helper-button reveal"><span class="mif-looks"></span></button>
                            </div>
                            <h3>New password:</h3>
                            <div class="input-control password " data-role="input" style="width: 50%">
                                <input name="new_pass" type="password" placeholder="Input your new password" data-validate-func="required, minlength" data-validate-arg=",8" data-validate-hint="password can not be empty or less than 8!" data-validate-hint-position="right"  required>
                                <button class="button helper-button reveal"><span class="mif-looks"></span></button>
                            </div>
                            <h3>Confirm password:</h3>
                            <div class="input-control password " data-role="input" style="width: 50%">
                                <input name="con_pass" type="password" placeholder="Input your new password" data-validate-func="required, minlength" data-validate-arg=",8" data-validate-hint="password can not be empty or less than 8!" data-validate-hint-position="right"  required>
                                <button class="button helper-button reveal"><span class="mif-looks"></span></button>
                            </div>
                            <br>
                            <input class="button" type="submit" name="" value="update">
                        </form>


                        <?php
                        }elseif ($edit=='details') {
                        ?>

                        <?php
                        $user=getInfo('users','WHERE id = '.$_SESSION['id']);
                        ?>
                        <form action="/fily/core/base/update-profile.php?update=details" method="post" data-role="validator">
                        <h3>Gender</h3>
                        <div class="input-control select">
                            <select name="gender">
                                <option value="male" <?php echo($user['0']['gender']=='male')? 'selected':';' ?> >Male</option>
                                <option value="female" <?php echo($user['0']['gender']=='female')? 'selected':';' ?> >Female</option>
                            </select>
                        </div>
                        <h3>Bio</h3>
                        <div class="input-control textarea" data-role="input" data-text-auto-resize="true" >
                            <textarea name="bio" placeholder="Input your bio" ><?php echo $user['0']['bio'] ?></textarea>
                        </div>
                        <h3>Birthday</h3>
                        <div class="input-control text" data-role="datepicker" data-scheme="navy" data-other-days="true" data-week-start="1" data-locale="en">
                            <input name="birthday" type="text" value="<?php echo $user['0']['birthday'] ?>" data-validate-func=" date" data-validate-hint="Value must be valid date string!" data-validate-hint-position="right"  required>
                            <button class="button"><span class="mif-calendar"></span></button>
                        </div>
                        <hr>
                        <h3>Favorit quote</h3>
                        <div class="input-control textarea"  data-role="input" data-text-auto-resize="true" >
                            <textarea name="fq_0" placeholder="Input your favorit quote"><?php echo explode('%',$user['0']['fav_quote'])[0] ?></textarea>
                        </div>
                        <h4>who said that?</h4>
                        <div class="input-control text">
                            <input name="fq_1" type="text" placeholder="Input who said it" value="<?php echo explode('%',$user['0']['fav_quote'])[1] ?>">
                        </div>
                        <h4>The source:</h4>
                        <div class="input-control text">
                            <input name="fq_2" type="text" placeholder="Input the source" value="<?php echo explode('%',$user['0']['fav_quote'])[2] ?>">
                        </div>
                        <br>
                            <input class="button" type="submit" name="" value="update">

                        </form>

                        <?php
                        }elseif ($edit=='files'){
                            foreach (getInfo('files','WHERE user_id = '.$_SESSION['id']) as $file) {
                            ?>
                            <div class=" block-shadow bd-gray" style="padding: 5px;border:1px solid;margin-bottom:5px;">
                                <div class="grid condensed ">
                                    <div class="row cells4">
                                    <div class="cell " style="overflow: hidden;"><b><?php echo $file['name'] ?></b></div>
                                    <div class="cell " ><?php echo $file['type'] ?></div>
                                    <div class="cell " >downloads:<b><?php echo $file['downloads'] ?></b></div>
                                    <div class="cell " ><a href="index.php?page=file&do=edit&id=<?php echo $file['id']; ?>" class="button mini-button" style="padding-top:0px">edit</a><a href="index.php?page=file&do=remove&id=<?php echo $file['id']; ?>" style="padding-top:0px" class="button mini-button danger">remove</a></div>
                                    </div>
                                </div>
                            </div>
                            <?php
                            }
                        }elseif ($edit=='des_del'){
                        if (getCount('id','users WHERE group_id = 1')!=1) {
                        ?>

                        <form action="/fily/core/base/update-profile.php?update=deactivate" method="post" data-role="validator">
                            <h3>Deactivate the account <small>(Block the account)</small></h3>
                            <div class="padding20 bg-orange  fg-darkRed" style="width: 100%">
                                <strong >Warning!</strong> once you deactivate your account, only the admin who can activate it again!
                            </div>
                            <br>
                            <input class="button warning block-shadow-error text-shadow" type="submit" value="Deactivate my account">
                        </form>
                        <br><br>
                        <hr>
                        <form action="/fily/core/base/update-profile.php?update=delete" method="post" data-role="validator">
                            <h3>Delete the account <small>(Fully remove the account)</small></h3>
                            <div class="padding20 bg-red  fg-darkRed" style="width: 100%">
                                <strong >Warning!</strong> once you deactivate your account, only the admin who can activate it again!
                            </div>
                            <br>
                            <input class="button danger block-shadow-danger text-shadow" type="submit" value="Deactivate my account">
                        </form>
                        <?php
                        }else{
                            ?>
                            <h2 class="fg-gray"><strong class="grayDark">Sorry!</strong> you are the only admin here we can't stop your account untill you set another admin with you.</h2>
                            <?php
                        }
                        }

                        ?>
                    </div>
                </div>
            </div>            
        </div>

        <?php
    }
