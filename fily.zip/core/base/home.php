<?php
if (!isset($_SESSION['id'])) {
    header('location:index.php');
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel='shortcut icon' type='image/x-icon' href='favicon.ico' />
    <title>Fily</title>
    <!--  setting the css  -->
    <link href="<?php echo $css; ?>/metro.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-colors.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-icons.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-responsive.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-rtl.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-schemes.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/style.css" rel="stylesheet">
    <!--  setting the js  -->
    <script src="<?php echo $js; ?>/jquery.js"></script>
    <script src="<?php echo $js; ?>/metro.js"></script>
    <script src="<?php echo $js; ?>/select2.min.js"></script>
    <script src="<?php echo $js; ?>/ga.js"></script>
    <script src="<?php echo $js; ?>/main.js"></script>


    <style>
        .tile-area-controls {
            position: fixed;
            right: 40px;
            top: 40px;
        }

        .tile-group {
            left: 100px;
        }

        .tile, .tile-small, .tile-sqaure, .tile-wide, .tile-large, .tile-big, .tile-super {
            opacity: 0;
            -webkit-transform: scale(.8);
            transform: scale(.8);
        }

        #charmSettings .button {
            margin: 5px;
        }

        .schemeButtons {
            /*width: 300px;*/
        }

        @media screen and (max-width: 640px) {
            .tile-area {
                overflow-y: scroll;
            }
            .tile-area-controls {
                display: none;
            }
        }

        @media screen and (max-width: 320px) {
            .tile-area {
                overflow-y: scroll;
            }

            .tile-area-controls {
                display: none;
            }

        }
    </style>



    <script>
        (function($) {
            $.StartScreen = function(){
                var plugin = this;
                var width = (window.innerWidth > 0) ? window.innerWidth : screen.width;

                plugin.init = function(){
                    setTilesAreaSize();
                    if (width > 640) addMouseWheel();
                };

                var setTilesAreaSize = function(){
                    var groups = $(".tile-group");
                    var tileAreaWidth = 80;
                    $.each(groups, function(i, t){
                        if (width <= 640) {
                            tileAreaWidth = width;
                        } else {
                            tileAreaWidth += $(t).outerWidth() + 80;
                        }
                    });
                    $(".tile-area").css({
                        width: tileAreaWidth
                    });
                };

                var addMouseWheel = function (){
                    $("body").mousewheel(function(event, delta, deltaX, deltaY){
                        var page = $(document);
                        var scroll_value = delta * 50;
                        page.scrollLeft(page.scrollLeft() - scroll_value);
                        return false;
                    });
                };

                plugin.init();
            }
        })(jQuery);

        $(function(){
            $.StartScreen();

            var tiles = $(".tile, .tile-small, .tile-sqaure, .tile-wide, .tile-large, .tile-big, .tile-super");

            $.each(tiles, function(){
                var tile = $(this);
                setTimeout(function(){
                    tile.css({
                        opacity: 1,
                        "-webkit-transform": "scale(1)",
                        "transform": "scale(1)",
                        "-webkit-transition": ".3s",
                        "transition": ".3s"
                    });
                }, Math.floor(Math.random()*500));
            });

            $(".tile-group").animate({
                left: 0
            });
        });

        function showCharms(id){
            var  charm = $(id).data("charm");
            if (charm.element.data("opened") === true) {
                charm.close();
            } else {
                charm.open();
            }
        }

        function setSearchPlace(el){
            var a = $(el);
            var text = a.text();
            var toggle = a.parents('label').children('.dropdown-toggle');

            toggle.text(text);
        }

        $(function(){
            var current_tile_area_scheme = localStorage.getItem('tile-area-scheme') || "tile-area-scheme-dark";
            $(".tile-area").removeClass (function (index, css) {
                return (css.match (/(^|\s)tile-area-scheme-\S+/g) || []).join(' ');
            }).addClass(current_tile_area_scheme);

            $(".schemeButtons .button").hover(
                    function(){
                        var b = $(this);
                        var scheme = "tile-area-scheme-" +  b.data('scheme');
                        $(".tile-area").removeClass (function (index, css) {
                            return (css.match (/(^|\s)tile-area-scheme-\S+/g) || []).join(' ');
                        }).addClass(scheme);
                    },
                    function(){
                        $(".tile-area").removeClass (function (index, css) {
                            return (css.match (/(^|\s)tile-area-scheme-\S+/g) || []).join(' ');
                        }).addClass(current_tile_area_scheme);
                    }
            );

            $(".schemeButtons .button").on("click", function(){
                var b = $(this);
                var scheme = "tile-area-scheme-" +  b.data('scheme');

                $(".tile-area").removeClass (function (index, css) {
                    return (css.match (/(^|\s)tile-area-scheme-\S+/g) || []).join(' ');
                }).addClass(scheme);

                current_tile_area_scheme = scheme;
                localStorage.setItem('tile-area-scheme', scheme);

                showSettings();
            });
        });

        var weather_icons = {
            'clear-day': 'mif-sun',
            'clear-night': 'mif-moon2',
            'rain': 'mif-rainy',
            'snow': 'mif-snowy3',
            'sleet': 'mif-weather4',
            'wind': 'mif-wind',
            'fog': 'mif-cloudy2',
            'cloudy': 'mif-cloudy',
            'partly-cloudy-day': 'mif-cloudy3',
            'partly-cloudy-night': 'mif-cloud5'
        };

        var api_key = 'AIzaSyDPfgE0qhVmCcy-FNRLBjO27NbVrFM2abg';

        $(function(){
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position){
                    var lat = position.coords.latitude, lon = position.coords.longitude;
                    var pos = lat+','+lon;
                    var latlng = new google.maps.LatLng(lat, lon);
                    var geocoder = new google.maps.Geocoder();
                    $.ajax({
                        url: '//api.forecast.io/forecast/219588ba41dedc2f1019684e8ac393ad/'+pos+'?units=si',
                        dataType: 'jsonp',
                        success: function(data){
                            //do whatever you want with the data here
                            geocoder.geocode({latLng: latlng}, function(result, status){
                                console.log(result[3]);
                                $("#city_name").html(result[3].formatted_address);
                            });
                            var current = data.currently;
                            //$('#city_name').html(response.city+", "+response.country);
                            $("#city_temp").html(Math.round(current.temperature)+" &deg;C");
                            $("#city_weather").html(current.summary);
                            $("#city_weather_daily").html(data.daily.summary);
                            $("#weather_icon").addClass(weather_icons[current.icon]);
                            $("#pressure").html(current.pressure);
                            $("#ozone").html(current.ozone);
                            $("#wind_bearing").html(current.windBearing);
                            $("#wind_speed").html(current.windSpeed);
                            $("#weather_bg").css({
                                'background-image': 'url(../images/'+current.icon+'.jpg'+')'
                            });
                        }
                    });
                });
            }
        });
    </script>

</head>
<body style="overflow-y: hidden;">
    <div style=" background-image:url('<?php echo getInfo('users','WHERE id = '.$_SESSION['id'])['0']['bg_img'] ?>');  background-size: cover; display: block; filter: blur(10px); -webkit-filter: blur(10px); height: 800px; left: 0; position: fixed; right: 0; z-index: 1;"></div>
    <div style="z-index: 5">
    <div data-role="charm" id="charmSearch" style="box-shadow: -3px 0 10px #000">
        <h1 class="text-light">Search</h1>
        <hr class="thin"/>
        <br />
        <div class="input-control text full-size">
            <label>
                <span class="dropdown-toggle drop-marker-light">Anywhere</span>
                <ul class="d-menu" data-role="dropdown">
                    <li><a onclick="setSearchPlace(this)">Anywhere</a></li>
                    <li><a onclick="setSearchPlace(this)">Options</a></li>
                    <li><a onclick="setSearchPlace(this)">Files</a></li>
                    <li><a onclick="setSearchPlace(this)">Internet</a></li>
                </ul>
            </label>
            <input type="text">
            <button class="button"><span class="mif-search"></span></button>
        </div>
    </div>
    <div data-role="charm" id="charmSettings" data-position="top" style="box-shadow: 0 3px 10px #000">
        <h1 class="text-light">Settings</h1>
        <hr class="thin"/>
        <br />
        <div class="schemeButtons">
            <div class="button square-button tile-area-scheme-dark" data-scheme="dark"></div>
            <div class="button square-button tile-area-scheme-darkBrown" data-scheme="darkBrown"></div>
            <div class="button square-button tile-area-scheme-darkCrimson" data-scheme="darkCrimson"></div>
            <div class="button square-button tile-area-scheme-darkViolet" data-scheme="darkViolet"></div>
            <div class="button square-button tile-area-scheme-darkMagenta" data-scheme="darkMagenta"></div>
            <div class="button square-button tile-area-scheme-darkCyan" data-scheme="darkCyan"></div>
            <div class="button square-button tile-area-scheme-darkCobalt" data-scheme="darkCobalt"></div>
            <div class="button square-button tile-area-scheme-darkTeal" data-scheme="darkTeal"></div>
            <div class="button square-button tile-area-scheme-darkEmerald" data-scheme="darkEmerald"></div>
            <div class="button square-button tile-area-scheme-darkGreen" data-scheme="darkGreen"></div>
            <div class="button square-button tile-area-scheme-darkOrange" data-scheme="darkOrange"></div>
            <div class="button square-button tile-area-scheme-darkRed" data-scheme="darkRed"></div>
            <div class="button square-button tile-area-scheme-darkPink" data-scheme="darkPink"></div>
            <div class="button square-button tile-area-scheme-darkIndigo" data-scheme="darkIndigo"></div>
            <div class="button square-button tile-area-scheme-darkBlue" data-scheme="darkBlue"></div>
            <div class="button square-button tile-area-scheme-lightBlue" data-scheme="lightBlue"></div>
            <div class="button square-button tile-area-scheme-lightTeal" data-scheme="lightTeal"></div>
            <div class="button square-button tile-area-scheme-lightOlive" data-scheme="lightOlive"></div>
            <div class="button square-button tile-area-scheme-lightOrange" data-scheme="lightOrange"></div>
            <div class="button square-button tile-area-scheme-lightPink" data-scheme="lightPink"></div>
            <div class="button square-button tile-area-scheme-grayed" data-scheme="grayed"></div>
        </div>
    </div>


    <div class="tile-area tile-area-scheme-dark fg-white" style="height: 100%; max-height: 100% !important;">
        <h1 class="tile-area-title text-shadow" style="z-index: 5"><b>Home</b></h1>
        <div class="tile-area-controls" style="z-index: 5">
            <a href="?page=profile" class="image-button icon-right bg-gray fg-dark fg-hover-gray bg-hover-dark no-border shadow"><span class="sub-header  no-margin text-light"><?php echo $_SESSION['username'] ?></span> <span class="icon mif-user fg-hover-dark"></span></a>
            <button class="square-button bg-gray fg-dark fg-hover-gray bg-hover-dark no-border shadow" onclick="showCharms('#charmSearch')"><span class="mif-search"></span></button>
            <button  class="square-button bg-gray fg-dark fg-hover-gray bg-hover-dark no-border shadow" onclick="showCharms('#charmSettings')"><span class="mif-cogs"></span></button>
            <a href="?page=profile&do=edit" class="square-button bg-gray fg-dark fg-hover-gray bg-hover-dark no-border shadow" ><span class="mif-cog"></span></a>
            <a href="/fily/core/functions/logout.php" class="square-button bg-gray fg-dark fg-hover-gray bg-hover-dark no-border shadow"><span class="mif-switch"></span></a>
        </div>

        <div class="tile-group double" style="z-index: 5">
            <span class="tile-group-title text-shadow">General</span>

            <div class="tile-container">

                <a href="index.php?page=profile" class="tile bg-indigo fg-white" data-role="tile">
                    <div class="tile-content zooming">
                        <div class="slide">
                            <img style="width: 100%; height: 100%" src="/fily/<?php echo getInfo('users','WHERE id = '.$_SESSION['id'])['0']['profile_img'] ?>">    
                        </div>
                    </div>
                    <span class="tile-label text-shadow">Profile</span>
                </a>

                <div class="tile bg-darkBlue fg-white" data-role="tile" onclick="document.location.href='index.php?page=browser'">
                    <div class="tile-content iconic">
                        <span class="icon mif-files-empty"></span>
                    </div>
                    <span class="tile-label">Browser</span>
                    <span class="tile-badge bg-darkRed"><?php echo getCount('files') ?></span>
                </div>

                <div class="tile-large bg-steel fg-white" data-role="tile" data-on-click="document.location.href='http://forecast.io'">
                    <div class="tile-content" id="weather_bg" style="background: top left no-repeat; background-size: cover">
                        <div class="padding10">
                            <h1 id="weather_icon" style="font-size: 6em;position: absolute; top: 10px; right: 10px;"></h1>
                            <h1 id="city_temp"></h1>
                            <h2 id="city_name" class="text-light"></h2>
                            <h4 id="city_weather"></h4>
                            <p id="city_weather_daily"></p>

                            <p class="no-margin text-shadow">Pressure: <span class="text-bold" id="pressure"></span> mm</p>
                            <p class="no-margin text-shadow">Ozone: <span class="text-bold" id="ozone"></span></p>
                            <p class="no-margin text-shadow">Wind bearing: <span class="text-bold" id="wind_bearing"></span></p>
                            <p class="no-margin text-shadow">Wind speed: <span class="text-bold" id="wind_speed">0</span> m/s</p>
                        </div>
                    </div>
                    <span class="tile-label">Weather</span>
                </div>
            </div>
        </div>

        <div class="tile-group double" style="z-index: 5">
            <span class="tile-group-title text-shadow">Images</span>
            <div class="tile-container">
                <div class="tile-large"  data-role="tile" data-effect="slideLeft">
                    <div class="tile-content slide-up">
                    <?php
                    foreach (getInfo('files','WHERE extension = "jpg" OR extension = "png" ORDER BY last_edit LIMIT 10') as $file) {
                    ?>
                    <div class="silde">
                        <a href="index.php?page=perview&id=<?php echo $file['id'] ?>" class="live-slide"><img src="/fily/data/upload/<?php echo $file['unique_name'] ?>" data-role="fitImage" data-format="fill"></a> 
                    </div>   
                    <?php
                    }
                    ?>
                    </div>
                    <div class="tile-label fg-dark text-shadow">Last 10 images</div>
                </div>
                <div class="tile bg-black fg-white" data-role="tile" onclick="document.location.href='index.php?order=last_edit&ow=DESC&need=picture'" class="shadow">
                    <div class="tile-content iconic">
                        <span class="icon mif-file-image"></span> 
                    </div>
                    <div class="tile-label">Photos</div>
                </div>
                <div class="tile-small bg-amber fg-white" data-role="tile" onclick="document.location.href='index.php?order=last_edit&ow=DESC&need=video'" class="shadow">
                    <div class="tile-content iconic">
                        <span class="icon mif-video-camera"></span>
                    </div>
                </div>
                <div class="tile-small bg-green fg-white" data-role="tile" onclick="document.location.href='index.php?order=last_edit&ow=DESC&need=book'" class="shadow">
                    <div class="tile-content iconic">
                        <span class="icon mif-file-pdf"></span>
                    </div>
                </div>
                <div class="tile-small bg-pink fg-white" data-role="tile" onclick="document.location.href='index.php?order=last_edit&ow=DESC&need=audio'" class="shadow">
                    <div class="tile-content iconic">
                        <span class="icon mif-headphones"></span>
                    </div>
                </div>
                <div class="tile-small bg-yellow fg-white" data-role="tile" onclick="document.location.href='index.php?order=last_edit&ow=DESC&need=compressed'" class="shadow">
                    <div class="tile-content iconic">
                        <span class="icon mif-file-archive"></span>
                    </div>
                </div>

            </div>
        </div>


        <div class="tile-group double" style="z-index: 5">
            <span class="tile-group-title text-shadow">Music</span>
            <div class="tile-container">

            <div data-role="audio" class="shadow">
                <div class="play-list-wrapper">
                    <h1 class="album-title" class="text-shadow">Top 10 shared music</h1>
                    <ul class="play-list">
                        <?php foreach (getInfo('files','WHERE extension = "mp3" ORDER BY downloads LIMIT 10') as $music) { ?>
                        <li data-src="http://127.0.0.1/fily/data/upload/<?php echo $music['unique_name'] ?>" data-type="audio/mp3"><?php echo $music['name'] ?></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
            </div>
        </div>

        <?php $videos=getInfo('files','WHERE extension = "mp4" ORDER BY last_edit LIMIT 2') ?>

        <div class="tile-group double" style="z-index: 5">
            <span class="tile-group-title text-shadow">Videos</span>
            <div class="tile-container" >
            <h1 class="text-shadow">Last videos</h1>
            <?php foreach ($videos as $video): ?>
                <div style="min-width: 340px" class="shadow" data-role="video" data-full-screen-mode="default" data-logo="/fily/theme/img/dflt/wn8.png"  data-preload="true" >
                    <video>
                        <source src="http://127.0.0.1/fily/data/upload/<?php echo $video['unique_name'] ?>" type='video/mp4' />
                    </video>
                </div><br>                
            <?php endforeach ?>
            </div>
        </div>
        <div class="tile-group double" style="z-index: 5">
            <span class="tile-group-title text-shadow">users</span>
            <div class="tile-container" >
                <h1 class="text-shadow">Most active users</h1>

            </div>
        </div>
    </div>
    </div>
</body>

    <script src="<?php echo $js; ?>/wallpaper.js"></script>
    <script src="<?php echo $js; ?>/jquery.nicescroll.js"></script>
</html>