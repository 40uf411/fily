<?php
echo "4";
if (isset($_SESSION['id']) && getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']==1 ) {
	if ($_GET['do']=='block') {
	$stmt=$db->prepare("UPDATE users SET active = 0 WHERE `users`.`id` = ?");
	$stmt->execute(array($_GET['id']));
	header('location:'.$_SERVER['HTTP_REFERER']);
	}

}else{
	header('location:'.$_SERVER['HTTP_REFERER']);
}
echo "5";