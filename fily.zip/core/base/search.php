<div class="container page-content">
<?php

    $option=(isset($_GET['option']) && in_array($_GET['option'],array('files','users','categories')))? $_GET['option']: 'files';

    ?>
    <div class="srch-page">
        <h1 style="font-size: 60px;">Search</h1>
        <form action="index.php?page=search-result" method="GET">
        <input type="hidden" name="page" value="search-result">
         <input type="hidden" name="option" value="<?php echo $option ?>">   
        
        <div class="input-control text full-size split-button" data-role="input">

            <button class="button split dropdown-toggle"></button>
            <input style="padding-right: 58px;" type="text" name="name">
            <div class="button-group">
                <button class="button dropdown-toggle">Options</button>
                <button class="button" type="submit"><span class="mif-search"></span></button>
                <ul class="split-content d-menu place-right navy" data-role="dropdown">
                    <li><a href="?page=search&option=files">Files</a></li>
                    <li><a href="?page=search&option=users">Users</a></li>
                    <li><a href="?page=search&option=categories">Categories</a></li>
                </ul>
            </div>
        </div>
 <?php
 
if ($option=='files') {
 echo '        
        <br><br>
        <h1>options:</h1>
        <div class="grid">
            <div class="row cells4">
                <div class="cell">
                    <h3>Category:</h3>
                    <div class="input-control select" style="display: block;">
                        <select name="cat_id">
                            <option value="all">All</option>';

                        foreach (getInfo('categories','ORDER BY name') as $cat) {
                            echo '<option value="'.$cat['id'].'">'.$cat['name'].'</option>';
                        }                        
echo                    '</select>
                    </div>                    
                </div>';
echo '          <div class="cell">
                    <h3>Date:</h3>
                    <div class="input-control select" style="display: block;">
                        <select>
                            <option value="'.Date('Y-m-d').'">Today</option>
                            <option value="'.Date('Y-m-d-1').'">Yesterday</option>
                            <option>last week</option>
                            <option>last month</option>
                        </select>
                    </div>                    
                </div>';

echo '          <div class="cell">
                    <h3>Type:</h3>
                    <div class="input-control select" style="display: block;">
                        <select name="extension">
                            <option value="all">All </option>
                            <option value="ai">Ai </option>
                            <option value="avi">Avi</option>
                            <option value="css">Css</option>
                            <option value="csv">Csv</option>
                            <option value="dbf">Dbf</option>
                            <option value="doc">Doc</option>
                            <option value="dwg">Dwg</option>
                            <option value="exe">Exe</option>    
                            <option value="fla">Fla</option>
                            <option value="html">Html</option>
                            <option value="iso">iso</option>
                            <option value="dOC">DOC</option>
                            <option value="jpg">Jpg</option>
                            <option value="js">Js </option>
                            <option value="json">Json</option>
                            <option value="mp3">Mp3</option>
                            <option value="mp4">Mp4</option>
                            <option value="pdf">Pdf</option>
                            <option value="png">Png</option>
                            <option value="ppt">Ppt</option>
                            <option value="psd">Psd</option>
                            <option value="rtf">Rtf</option>
                            <option value="txt">Txt</option>
                            <option value="xls">Xls</option>
                            <option value="xml">Xml</option>
                            <option value="zip">Zip</option>                                                                                
                        </select>
                    </div>                    
                </div>';
echo '          <div class="cell">
                    <h3>Size:</h3>
                    <div class="input-control select" style="display: block;">
                        <select name="size">
                            <option value="all">All</option>
                            <option value="5120"> < 500kb</option>
                            <option value="10485760"> < 10Mb</option>
                            <option value="52428800"> < 50Mb<</option>
                        </select>
                    </div>                    
                </div>
            </div>
        </div>';


 } 
?>
     </form>   
    </div>
</div>
    <?php