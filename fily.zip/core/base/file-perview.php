?>
<div class="container page-content">


<?php
    if (isset($_GET['id']) && checkExist('files',$_GET['id'])) {
    $stmt=$db->prepare("SELECT files.*,
    categories.name AS category_name,
    users.username AS username,
    users.group_id AS grade
    FROM files
    INNER JOIN
    categories
    ON
    categories.id=files.cat_id
    INNER JOIN
    users
     ON
    users.id=files.user_id
    WHERE files.id= ?
    ORDER BY last_edit DESC ");
    $stmt->execute(array($_GET['id']));
    $file=$stmt->fetch();
    echo '  <div class="item-container bg-white shadow bd-darkCobalt">
        <div class="grid no-margin-top">
        <ul class="breadcrumbs ">
                    <li><a href="index.php"><span class="icon mif-home"></span></a></li>
                    <li><a href="index.php?page=profile&id='.$file['user_id'].'"><b>'.$file['username'].'</b></a></li>
                    <li><a href="#">'.$file['category_name'].'</a></li>
                    <li><a href="?page=perview&id='.$file['id'].'">'.$file['name'].'</a></li>';
                                            if (isset($_SESSION['id'])) {

                        echo'
                        <div class="dropdown-button place-right">
                            <button class="split dropdown-toggle bg-focus-darkCyan "></button>
                            <ul class="split-content d-menu place-right navy shadow" data-role="dropdown" >';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$file['user_id']) {

                        echo   '<li><a href="index.php?page=file&do=edit&id='.$file['id'].'">Edit File</a></li>';
                        }
                        if ($_SESSION['id']!=$file['user_id']) {
                        echo'   <li><a href="index.php?page=file&do=report&id='.$file['id'].'">Report file</a></li>';
                        }
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' && $_SESSION['id']!=$file['user_id']) {
                        echo   '<li><a href="#">Send an Alert to '.$file['username'].'</a></li>';
                        }
                        echo   '<li class="divider"></li>';
                        if (getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' || $_SESSION['id']==$file['user_id']) {
                        echo   '<li><a href="index.php?page=file&do=remove&id='.$file['id'].'" class="fg-crimson bg-hover-crimson fg-hover-white"> Remove File</a></li>';
                        }
                        if ( $file['user_id']!=1 && getInfo('users','WHERE id = '.$_SESSION['id'])['0']['group_id']=='1' ) {        
                        echo   '<li><a href="#" class="bg-darkRed bg-hover-crimson"><span class="mif-blocked"></span> Block '.$file['username'].'</a></li>';
                        }
                        echo   '</ul>
                        </div>';
                        }
                        echo'

                </ul>
            <div class="row cells3">
                        <div class="cell2">
                            <div class="';  
                            if($file['extension']=='pdf' || $file['extension']=='fla' || $file['extension']=='flash'){
                                echo "bg-red bd-red";
                            }elseif ($file['extension']=='ai' || $file['extension']=='js' || $file['extension']=='svg' || $file['extension']=='xml') {
                                echo "bg-amber bd-amber";
                            }elseif ($file['extension']=='avi' || $file['extension']=='csv' || $file['extension']=='mp4') {
                                echo "bg-magenta bd-magenta";
                            }elseif ($file['extension']=='css' || $file['extension']=='doc' || $file['extension']=='dwg' || $file['extension']=='psd' || $file['extension']=='rtf') {
                                echo "bg-darkCobalt bd-darkCobalt";
                            }elseif ($file['extension']=='html' || $file['extension']=='ppt') {
                                echo "bg-orange bd-orange";
                            }elseif ($file['extension']=='iso' || $file['extension']=='png' || $file['extension']=='jpg') {
                                echo "bg-green bd-green";
                            }elseif ($file['extension']=='txt' || $file['extension']=='zip' || $file['extension']=='') {
                                echo "bg-grayDarker bd-grayDarker";
                            }elseif ($file['extension']=='exe' || $file['extension']=='mp3' || $file['extension']=='json') {
                                echo "bg-darkViolet bd-darkViolet";
                            }
                            echo ' tile type-img" data-role="tile">
                                <img src="/fily/data/default_types/'.$file['extension'].'.png">
                            </div>                   
                </div>
                
                <div class="cell3">
                    <h1 class="leader itm-ttl"> '.$file['name'].'</h1>
                    <h4>Shared at: '.$file['add_date'].'</h4>
                </div>

            </div>
            <div class="row cells3 file-info">
                <ul class="file-prvw">
                    <li><b>Name:</b>'.$file['name'].'</li>
                    <li><b>Added By:</b><a href="index.php?page=profile&id='.$file['user_id'].'"> '.$file['username'].'</a></li>
                    <li><b>Category:</b> '.$file['category_name'].'</li>
                    <li><b>Type:</b> '.$file['type'].'</li>
                    <li><b>Description:</b> '.$file['description'].'</li>
                    <li><b>Extension:</b> '.$file['extension'].'</li>
                    <li><b>Size: </b>';
                        if ($file['size']>=1073741824){
                            echo intval($file['size']/1073741824);
                            echo ' GB';
                        }elseif ($file['size']>=1048576) {
                            echo intval($file['size']/1048576);
                            echo ' MB';
                        }elseif ($file['size']>=1024) {
                            echo intval($file['size']/1024);
                            echo ' kB';
                        }else{
                            echo $file['size'];
                            echo ' B';
                        }
                    echo '</li>
                    <li><b>Last update:</b> '.$file['last_edit'].'</li>
                    <li><b>Download times:</b> '.$file['downloads'].'</li>
                </ul>
            </div>
             <div class=" cells3 place-right">
                <div class="cell2 " style="margin-right: 10px">
                    <a class="button" href="core/functions/download.php?id='.$file['id'].'" ><i class="mif-file-download"></i> Download</a>
                </div>                  
            </div>
        </div>  
    </div>';
    }else{
        header('location:index.php');
    }
   
