<?php
if (isset($_SESSION['id'])) {

?>  
    <div class="container page-content">
    <div class=" edit-page padding20 bd-darkCobalt margin40 no-margin-top">
    <div class="grib">

    <form action="/core/functions/f-upload.php" method="post" enctype="multipart/form-data">
        <div class="row cells1">
            <div class="cell ">
                <h1>Upload File</h1>
                <div class="margin20">
                    <h3>Select the file:</h3>
                    <div class="input-control file" data-role="input">
                        <input type="file" name="file">
                        <button class="button"><span class="mif-folder"></span></button>
                    </div>                    
                </div>
    

                <div class="margin20">
                    <h3>Name: </h3> <div class="input-control text"><input type="text" name="name" placeholder="Input a new name " value=""> <input type="hidden" name="extension" value=""> </div><br>
                </div>
                <div class="margin20">
                    <h3>Description: </h3>
                    <div class="input-control textarea" data-role="input" data-text-auto-resize="true" data-text-max-height="200">
                        <textarea name="description" style="resize:none" placeholder="Input a new description"></textarea>
                    </div>
                </div>
                <div class="margin20">
                    <h3>Category</h3>
                    <div class="input-control select">
                        <select name="cat_id">
                        <?php foreach (getInfo('Categories') as $cat): ?>
                            <option value="<?php echo $cat['id'] ?>"><?php echo $cat['name'] ?></option>
                        <?php endforeach ?>
                        </select>
                    </div>
                </div>    
            </div>

        </div>
        <div class="row cells1">
            <!--<div class="cell place-left">
                <a href="index.php?page=file&do=remove&id=<?php echo $file['0']['id'] ?>" class="margin20 button danger ">Remove file</a>
            </div>-->
            <div class="cell place-right">
                <a href="index.php" class="margin20 button danger block-shadow-danger text-shadow">Cancel</a>
                <a><input type="submit" value="Apply" class="margin20 button primary block-shadow-primary text-shadow"></a>
            </div>
        </div>
    </form>

    </div>

    </div>               

    <?php
    }else{
        ?>      
            <div class="container page-content">
            <div class=" edit-page padding20 bd-darkRed bg-darkRed fg-red margin40 no-margin-top align-center">
                <h1><b>Access denied!</b></h1>
                <p>You must log in first to see this page.</p>
                <a href="index.php" class="button danger fg-darkRed fg-active-red">Go back!</a>
            </div>
        <?php
    }