<?php
$nonav=$nohead='';
require '../../config.php';
if (!isset($_SESSION['id'])) {
	header('location:'.$_SERVER['HTTP_REFERER']);
}
if($_GET['update']=='general'){

	if(!isset($_POST['username']) || strlen($_POST['username'])<4 ){$errors[]='';}
	if(!isset($_POST['fullName']) || strlen($_POST['fullName'])<4){$errors[]='';}
	if(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)){$errors[]='';}
	if (!empty($errors)) {
	header('location:'.$_SERVER['HTTP_REFERER']);
	}else{
        $stmt=$db->prepare("UPDATE users SET username=?, fullName=?, email=? WHERE `users`.`id` = ?");
        $stmt->execute(array($_POST['username'],$_POST['fullName'],$_POST['email'],$_SESSION['id']));
        $_SESSION['username']=$_POST['username'];
        header("location:".$_SERVER['HTTP_REFERER']);

	}



}elseif($_GET['update']=='security'){ 

	if(!isset($_POST['old_pass']) || strlen($_POST['old_pass'])<8){$errors[]='';}
	if(!isset($_POST['new_pass']) || strlen($_POST['new_pass'])<8){$errors[]='';}
	if(!isset($_POST['con_pass']) || strlen($_POST['con_pass'])<8){$errors[]='';}
	if ( password_verify( $_POST['old_pass'] , getInfo('users','WHERE id = '.$_SESSION['id'] )['0']['password'] )==0 ){
		$errors[]='';
	}
	if ($_POST['new_pass']!==$_POST['con_pass']) {
		$errors[]='';
	}
	if (!empty($errors)) {
	header('location:'.$_SERVER['HTTP_REFERER']);
	}else{
        $stmt=$db->prepare("UPDATE users SET password=? WHERE `users`.`id` = ?");
        $stmt->execute(array(password_hash($_POST['new_pass'],PASSWORD_DEFAULT,['cost'=>12]),$_SESSION['id']));
        header("location:".$_SERVER['HTTP_REFERER']);

	}

		
}elseif($_GET['update']=='details'){

	if(isset($_POST['gender']) && in_array($_POST['gender'],['male','female'])){ $_POST['gender'];}else header('location:'.$_SERVER['HTTP_REFERER']);
	
	if (explode('-', $_POST['birthday'])[0]<=date('Y') && explode('-', $_POST['birthday'])[0]>1960 && explode('-', $_POST['birthday'])[1]<=12 && explode('-', $_POST['birthday'])[1]>0  && explode('-', $_POST['birthday'])[2]>0 && explode('-', $_POST['birthday'])[2]<31) {
		$birthday=$_POST['birthday'];
	}else{
		header("location:".$_SERVER['HTTP_REFERER']);
	}
	$fav_quote=$_POST['fq_0'].'%'.$_POST['fq_1'].'%'.$_POST['fq_2'].'%';

	    $stmt=$db->prepare("UPDATE users SET gender = ? , bio = ?, birthday = ?, fav_quote = ? WHERE `users`.`id` = ?");
        $stmt->execute(array($_POST['gender'],$_POST['bio'],$birthday,$fav_quote,$_SESSION['id']));
        header("location:".$_SERVER['HTTP_REFERER']);

}elseif($_GET['update']=='profile'){


	if (isset($_FILES['profile'])) {
	$file=$_FILES['profile'];

	/********************/
	$file['ext']=explode('.', $file['name']);
	$file['ext']=strtolower(end($file['ext']));
	$allowed=array('jpg','png');

	if (in_array($file['ext'], $allowed) && $file['error']==0) {
		
		 $file['unique_name']=uniqid(date('ymdhis').'-',false).'.'.$file['ext'];
		 $file['destination']='../../data/pro-img/'.$file['unique_name'];

		 if (move_uploaded_file($file['tmp_name'], $file['destination'])) {
		 	$stmt=$db->prepare("UPDATE users SET profile_img = ? WHERE `users`.`id` = ?");
		 	$stmt->execute(array('data/pro-img/'.$file['unique_name'],$_SESSION['id']));
		 	header('location:'.$_SERVER['HTTP_REFERER']);		 
		 }else{
			echo "3";
			header('location:'.$_SERVER['HTTP_REFERER']);
		}		

	}else{
		echo "3";
		header('location:'.$_SERVER['HTTP_REFERER']);
	}

}


}elseif($_GET['update']=='cover'){


	if (isset($_FILES['cover'])) {
		$file=$_FILES['cover'];

		/********************/
		$file['ext']=explode('.', $file['name']);
		$file['ext']=strtolower(end($file['ext']));
		$allowed=array('jpg','png');

		if (in_array($file['ext'], $allowed) && $file['error']==0) {
			
			 $file['unique_name']=uniqid(date('ymdhis').'-',false).'.'.$file['ext'];
			 $file['destination']='../../data/pro-img/'.$file['unique_name'];

			 if (move_uploaded_file($file['tmp_name'], $file['destination'])) {
			 	$stmt=$db->prepare("UPDATE users SET bg_img = ? WHERE `users`.`id` = ?");
			 	$stmt->execute(array('data/pro-img/'.$file['unique_name'],$_SESSION['id']));
			 	header('location:'.$_SERVER['HTTP_REFERER']);		 
			 }else{
				echo "3";
				header('location:'.$_SERVER['HTTP_REFERER']);
			}		

		}else{
			echo "3";
			header('location:'.$_SERVER['HTTP_REFERER']);
		}

	}


}elseif($_GET['update']=='deactivate'){
			 	$stmt=$db->prepare("UPDATE users SET active = 0 WHERE `users`.`id` = ?");
			 	$stmt->execute(array($_SESSION['id']));
			 	header('location:../functions/logout.php');
}elseif($_GET['update']=='delete'){
			 	$stmt=$db->prepare("DELETE FROM `users` WHERE `users`.`id` = ?");
			 	$stmt->execute(array($_SESSION['id']));
			 	header('location:../functions/logout.php');
}