<div>
    <header class="app-bar fixed-top my-nav navy shadow" data-role="appbar">

    <a class="app-bar-element branding" href="<?php echo (isset($_SESSION['id']))? 'http://127.0.0.1/fily/?page=home':'http://127.0.0.1/fily/'; ?>">Fily</a>
    <span class="app-bar-divider"></span>

    <ul class="app-bar-menu">
        <?php if (isset($_SESSION['id'])): ?>
            <li data-flexorderorigin="0" data-flexorder="1"><a href="index.php?page=home">Home</a></li>
        <?php endif ?>
        <li data-flexorder="3" data-flexorderorigin="2"><a href="index.php?page=browser">Browser Files</a></li>
        <li data-flexorderorigin="2" data-flexorder="1">
            <a href="" class="dropdown-toggle">Categories</a>
            <ul class="d-menu" data-role="dropdown">
            <?php 

            foreach (getInfo('categories','ORDER BY name LIMIT 7') as $cat){
                echo '<li><a href="?category='.$cat['id'].'">'.$cat['name'].'</a></li>';
            }
        
            ?>
            <li class="divider"></li>
            <li><a href="index.php?page=categories">View all <span class=" mif-chevron-right"></span> </a></li>
            </ul>
        </li>
        <li data-flexorder="3" data-flexorderorigin="4"><a href="http://127.0.0.1/fily/index.php?page=search">search</a></li>

    </ul>
    <div class="app-bar-pullbutton automatic" style="display: block;"></div>

    <div class="app-bar-element place-right">
        <?php if(!isset($_SESSION['username'])){
          echo '
        <div class="dropdown-toggle fg-white"><span class="mif-enter"></span> Enter</div>

        <div class="app-bar-drop-container bg-white fg-dark place-right" data-role="dropdown" data-no-close="true" style="display: none;">
            <div class="padding20">
                <form action="core/functions/login.php" method="POST">
                    <h4 class="text-light">Login to service...</h4>
                    <div class="input-control text">
                        <span class="mif-user prepend-icon"></span>
                        <input type="text" name="username">
                    </div>
                    <div class="input-control text">
                        <span class="mif-lock prepend-icon"></span>
                        <input type="password" name="password">
                    </div>
                    <label class="input-control checkbox small-check">
                                        <input type="checkbox" name="remember-me">
                                        <span class="check"></span>
                                        <span class="caption">Remember me</span>
                                    </label>
                    <div class="form-actions">
                        <input type="submit" class="button" value="login">
                        <button class="button link">Cancel</button>
                    </div>
                </form>
                <a class="button link" href="?page=signin">Creat new account</a>
            </div>
        </div>
        ';
        }else{ echo'
                    <div class="dropdown-toggle fg-white"><img class="profile-img itm-user-img" src="/fily/'.getProImg($_SESSION['username'])['profile_img'].'" > '.$_SESSION['username'].'</div>
                        <ul class="d-menu place-right shadow" data-role="dropdown">
                            <li><a class="bg-white fg-darkCyan fg-active-darkCobalt bg-hover-grayLighter " href="index.php?page=upload"><span class="mif-upload"></span> Upload new file</a></li>
                            <li><a href="index.php?page=profile"> Profile</a></li>
                            <li><a href="index.php?page=profile&do=edit"> Settings</a></li>
                            <li><a href=""> Logs</a></li>';
                            if (isadmin($_SESSION['id'])) {
                                echo '<li><a href="/fily/adminCP/"> Admin CP</a></li>';
                            }

                        echo'<li class="divider"></li>
                            <li><a href="core/functions/logout.php"><span class="mif-exit"></span> Logout</a></li>
                        </ul>';               
        }
        ?>
    </div>
    <div class="app-bar-divider place-right"></div>

    <div class="clearfix" style="width: 0;"></div>
    <nav class="app-bar-pullmenu hidden flexstyle-sidebar2" style="display: none;">
        <ul class="app-bar-pullmenubar hidden sidebar2"></ul>
        <ul class="app-bar-pullmenubar sidebar2" style="display: block;">
            <li data-flexorderorigin="0" data-flexorder="1" class="app-bar-pullmenu-entry">

            </li>
        </ul>
    </nav>
</header>

</div>