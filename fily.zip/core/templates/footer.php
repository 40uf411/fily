</div>
<div class="footer bg-darkCobalt">
    <div class="grid" style="margin-bottom: 0">
        <div class="row cells4">
            <div class="cell">
                <img class="footer-img" src="theme\img\dflt\word.png" >
            </div>

            <div class="cell contact-cell">
            	<h2>Quote</h2>
            	<p style="font-size: 20px; color: #2086bf">in these life seek for <b>your purpose</b> and once you find it stick on it tell <b>the last breath</b>. </p>
            </div>
            <div class="cell footer-links">
            	<h2>Important links</h2>
            	<div style="margin-bottom: 15px"><a href="">Support</a><br></div>
            	<div style="margin-bottom: 15px"><a href="">Help</a><br></div>
            	<div style="margin-bottom: 15px"><a href="">Privacy</a><br></div>
            	<div style="margin-bottom: 15px"><a href="">Terms</a><br></div>
            	<div style="margin-bottom: 15px"><a href="">FAQ</a><br></div>
            	<div style="margin-bottom: 15px"><a href="">About US</a><br></div>
            </div>
            <div class="cell contact-cell">
            	<h2>Contact</h2>
				<div class="input-control text">
				    <input type="text" placeholder="Input your email here...">
				</div><br>
				<div class="input-control text">
				    <input type="text" placeholder="Input the subject here...">
				</div><br>
				<div class="input-control textarea" data-role="input" data-text-auto-resize="true" data-text-max-height="200">
    				<textarea placeholder="Input the message here..."></textarea>
				</div>
				<div>
					<input class="button primary" type="submit" value="Send">
				</div>
											
            </div>
        </div>
        <div class="row  align-center copy">
        	<div class="cell">
        		Copyright&copy; 1999-2017 All rights reserved to <a href="">Ali Aouf</a>
        		<p style="margin: 0; font-size: 13px;color: rgba(255,255,255,.5);">Built and designed with all the <b>LOVE</b> in the world</p>
        	</div>
        </div>
        <div class="row  align-center">
        	<div class="cell">
	        	<a href="" class="ext-btns"><span class="mif-facebook"></span></a>
	        	<a href="" class="ext-btns"><span class="mif-twitter"></span></a>
	        	<a href="" class="ext-btns"><span class="mif-skype"></span></a>
	        	<a href="" class="ext-btns"><span class="mif-youtube-play"></span></a>
	        	<a href="" class="ext-btns"><span class="mif-linkedin"></span></a>
	        	<a href="" class="ext-btns"><span class="mif-github"></span></a>
        	</div>
        </div>
    </div>
</div>

