<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel='shortcut icon' type='image/x-icon' href='favicon.ico' />
	<title>Fily</title>
	<!--  setting the css  -->
    <link href="<?php echo $css; ?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/cropper.min.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/main.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-colors.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-icons.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-responsive.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-rtl.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/metro-schemes.css" rel="stylesheet">
    <link href="<?php echo $css; ?>/style.css" rel="stylesheet">
    <!--  setting the js  -->
    <script src="<?php echo $js; ?>/jquery.js"></script>
    <script src="<?php echo $js; ?>/metro.js"></script>
    <script src="<?php echo $js; ?>/select2.min.js"></script>
    <script src="<?php echo $js; ?>/ga.js"></script>
    <script src="<?php echo $js; ?>/main.js"></script>


</head>
<body>
	
