</body>

    <script src="<?php echo $js; ?>/wallpaper.js"></script>
    <script src="<?php echo $js; ?>/jquery.js"></script>
    <script src="<?php echo $js; ?>/bootstrap.min.js"></script>
    <script src="<?php echo $js; ?>/crop.js"></script>
</html>