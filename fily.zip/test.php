<?php
$f =  fopen("test.txt","r");
echo "current ";
echo $co = fread($f,5);
fclose($f);
echo "<br>next ";
echo $i = intval($co) + 1;
$f =  fopen("test.txt","w");
fwrite($f, $i);
fclose();
?>
    