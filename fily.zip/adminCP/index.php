<?php
session_start();

if(!isset($_SESSION['admin_username'])){
	$title='login';
	$nonav='';
	require 'config.php';
	require $base.'login.php';

}else{

header('location:dashboard.php');

}
require $tmp.'footer.php';
?>