<?php
$title='test';
require 'config.php';
?>
	
	<div class="container pull-right stng-page text-center" style="width: 78%">
		<div class="col-md-10">
			<div class="file text-left">
				<div class="file-header">
					<div class="img-fram">
						<img  src="<?php echo $img.'default_types/'; ?>pdf.png">	
					</div>
					<a href="#">
					<div class="owner">
						Ali Aouf
					</div></a>
					<span class="glyphicon glyphicon-triangle-right arrow"></span>
					<div class="tree">
						<ol class="breadcrumb breadcrumb-arrow">
		                  <li><a href="#"><i class="glyphicon glyphicon-home"></i> Home</a></li>
		                  <li><a href="#"><i class="glyphicon glyphicon-list-alt"></i> PL</a></li>
		                  <li class="active"><span><i class="glyphicon glyphicon-file"></i> How to java.pdf</span></li>
	                	</ol>
                	</div>

		            <div class="btn-group option-list">
			              <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
		                  <span class="caret"></span>
		                  <span class="sr-only">Toggle Dropdown</span>
				           </button>
				             <ul class="dropdown-menu" role="menu">
				               <li><a href="#"><span class="glyphicon glyphicon-pencil"></span> Edit this file</a></li>
				               <li><a href="#"><span class="glyphicon glyphicon-eye-close"></span> Hide this file</a></li>
				               <li><a href="#"><span class="glyphicon glyphicon-flag"></span> Send an alert to Ali</a></li>
				               <li class="divider"></li>
				               <li><a href="#"><span class="glyphicon glyphicon-trash"></span> Delete this file</a></li>
				               <li><a href="#"><span class="glyphicon glyphicon-remove"></span> Block Ali</a></li>
				             </ul>
			        </div>
                	<div class="date">
                		<p>12 Aug, 2017 at 12:00</p>
                	</div>
                	<div class="title">
                		<h2>How to java</h2>
                	</div>
                	
				</div>
				<div class=" file-info">
				<ul>
					<li><b><span class="glyphicon glyphicon-file"></span> name:</b> how to java <br></li>
					<li><b><span class="glyphicon glyphicon-user"></span> author:</b> Ali Aouf <br></li>
					<li><b><span class="glyphicon glyphicon-inbox"></span> type:</b> PDF <br></li>
					<li><b><span class="glyphicon glyphicon-hdd"></span> size:</b> 32MB <br></li>
					<li><b><span class="glyphicon glyphicon-download"></span> downloads:</b> 255 <br></li>
				</ul>
				</div>
				<div class="file-footer">
					<div class="pull-right file-buttons">
						<a class="btn btn-primary" href="#"><span class="glyphicon glyphicon-info-sign"></span> More Infos</a>
						<a class="btn btn-success" href="#"><span class="glyphicon glyphicon-download-alt"></span> Download</a>						
					</div>

				</div>
			</div>
		</div>
	</div>
</div>
<?php
require $tmp.'footer.php';
?>
