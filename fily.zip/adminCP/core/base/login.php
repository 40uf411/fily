<?php
if ($_SERVER['REQUEST_METHOD']=='POST') {
	//echo checkAdmin($_GET['admin_username']);

		if (checkAdmin($_POST['admin_username'],$_POST['admin_password'])) {
			$_SESSION['admin_username']=$_POST['admin_username'];
			$stmt=$db->prepare("UPDATE `users` SET `lastseen` = now() WHERE `users`.`username` = ?");
			$stmt->execute(array($_SESSION['admin_username']));

				$stmt= $db->prepare("SELECT active FROM users WHERE username =? ");
				$stmt->execute(array($_SESSION['admin_username']));
				if ($stmt->fetch()!=0) {
					$stmt=$db->prepare("UPDATE `users` SET `active` = 1 WHERE `users`.`username` = ?");
					$stmt->execute(array($_SESSION['admin_username']));					
				}

			header('location:'.$_SERVER['HTTP_REFERER']);
			exit();
		}else{
			$err='wrong password or username';
		}

}
?>

<h1 class="text-center">Admin panel</h1>
	<?php
		if (isset($err)) { ?>
			<div class="alert alert-danger alert-dismissable alrt">
                 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
         	     <h4>Sorry!</h4> wrong username or password
        	</div>			
		<?php } ?>
<form class="login" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
	<input class="form-control" type="text" name="admin_username" placeholder="username" autocomplete="off">
	<input class="form-control" type="text" name="admin_password" placeholder="password" autocomplete="new-password">
	<input class="btn btn-primary btn-block" type="submit" value="login">
</form>
