<?php
try{//try to connect to db
	$db = new PDO("mysql:host=localhost;dbname=fily",'root','');
}catch(PDOException $e){
	//if ther's any error show the error and exit
	echo 'Failed to connect '.$e->getMessage();
	die();
}
?>