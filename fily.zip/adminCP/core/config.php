<?php
//connect to the db
$cnct= 'core/cnct.php';
require $cnct;
//definitions
$mt='bootflat/'; //main theme
$theme='theme/';
//main routs
$func='/core/functions/';
$tmp='/core/templates/';
$css=$theme.$mt.'css';
$js=$theme.$mt.'js';
$js=$theme.$mt.'img';
//include the functions
require $func.'main.php';
require $tmp.'header.php';
?>