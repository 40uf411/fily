<?php

/*
** function to set the title for all the pages depanding on a variable called $title
*/
function gettitle()
{
	global $title;
	return $title;
}
/*
** function to check the username and the password of the admin 
*/

function checkAdmin($admin,$pass)
{
	global $db;
	$stmt= $db->prepare("SELECT username,password,active,group_id FROM users WHERE username = ? LIMIT 1");
	$stmt->execute(array($admin));
	$con = $stmt->fetch();
	if ($con['group_id']==0 || $con['active']==0) {
		return false;
	}else
	return ((password_verify($pass,$con['password'])==1) && ($admin==$con['username']))? true:false;
}
/*
** function return the count of items in a table
*/
function getCount($what,$where)
{
	global $db;
	$stmt= $db->prepare("SELECT $what FROM $where ");
	$stmt->execute();
	$con = $stmt->rowCount();
	return $con;	
}
/*
**
*/
function getInfo($where,$op=NUll)
{
	global $db;
	$stmt= $db->prepare("SELECT * FROM $where $op ");
	$stmt->execute();
	return $stmt->fetchAll();
}

/*
**
*/

function checkExist($haystack,$needle)
{
	global $db;
	$stmt= $db->prepare("SELECT id FROM $haystack WHERE id= ? ");
	$stmt->execute(array($needle));
	return ($stmt->rowCount()>0)? true:false;
}