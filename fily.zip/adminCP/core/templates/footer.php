
</body>
	<!-- site js -->
    <script type="text/javascript" src="<?php echo $js ?>jquery.js"></script>
    <script type="text/javascript" src="<?php echo $js ?>jquery.fs.selecter.min.js"></script>
    <script type="text/javascript" src="<?php echo $js ?>jquery.fs.stepper.min.js"></script>
    <script type="text/javascript" src="<?php echo $js ?>icheck.min.js"></script>
</html>