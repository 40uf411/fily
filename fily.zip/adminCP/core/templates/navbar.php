<div class="page">
<div class="v-nav pull-left">
	<div class="avatar">
		<img  src="<?php echo $img.'avatar.png' ?>">
	</div>
                  <?php 
                    $stmt= $db->prepare("SELECT id FROM users WHERE username=? ");
                    $stmt->execute(array($admin));
                    $usr =$stmt->fetchAll();
                 ?>
			<div class="btn-group">

                <a class="btn " title="Frontend" href="http://<?php echo $location ?>"><i class="glyphicon glyphicon-home"></i></a>
                <a class="btn " title="edit acount" href="users.php?do=edit&id=<?php echo $usr['0']['id'] ?>"><i class="glyphicon glyphicon-cog"></i></a>
                <a class="btn " title="logout" href="logout.php"><i class="glyphicon glyphicon-off"></i></a>
           	</div>
           	<div class="menu">
           		<hr>
           		<a class="btn a-selected" href="dashboard.php">Dashboard</a>
           		<hr>
           		<a class="btn" href="settings.php">Settings</a>
           		<hr>           		
           		<a class="btn" href="users.php">Users</a>
              <hr>
              <a class="btn" href="categories.php">categories</a>
           		<hr>
           		<a class="btn" href="files.php">Files</a>
           		<hr>
           		<a class="btn" href="reports.php">Reports</a>
           		<hr>
           		<a class="btn" href="alerts.php">Alerts</a>
           		<hr>
           		<a class="btn" href="logs.php">Logs</a>
           		<hr>

           	</div>
</div>