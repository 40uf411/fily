<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo(isset($title))? gettitle():'Admin CP'; ?></title>
	<!-- site css -->
    <link rel="stylesheet" href="<?php echo $css ?>bootstrap.css">
    <link rel="stylesheet" href="<?php echo $css ?>bootflat.css">
    <link rel="stylesheet" href="<?php echo $css ?>style.css">
    <!-- site js  -->
    <script type="text/javascript" src="<?php echo $js ?>site.min.js"></script>
</head>
<body>
