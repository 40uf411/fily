<?php
session_start();

if(!isset($_SESSION['admin_username'])){
	$title='login';
	$nonav='';
	require 'config.php';
	require $base.'login.php';

}else{
	$do=(isset($_GET['do']) && in_array($_GET['do'], array('manage','perview','edit','update','delete')))?$_GET['do']:'manage';
if ($do=='manage') {
	$title='files';
	require 'config.php';
		?>
		<div class="container pull-right users-page " style="width: 78%">
		<h1 class="text-center">manage files</h1>
			<div class="panel panel-primary">

              <div class="panel-heading">
              All the files
              </div>
              <?php if(isset($_GET['scs']) && $_GET['scs']==1){ ?>
            <div class="alert alert-success alert-dismissable big-green">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <strong>Done!</strong> All the changes have been saved successfuly.
            </div>
            <?php } ?>
              <div class="panel-body files-panel">

              		<table class="table table-responsive ">
              			<tr>
              				<th>##</th>
              				<th>File</th>
              				<th>size</th>
              				<th>category</th>
              				<th>adder</th>
              				<th>last edit</th>
              				<th>download times</th>
              				<th>control</th>
              			</tr>
              			<?php 
              			$stmt=$db->prepare("SELECT files.*,
              										categories.name AS category_name,
              										users.username AS username,
              										users.group_id AS grade
              										FROM files
              										INNER JOIN
              										categories
              										ON
              										categories.id=files.cat_id
              										INNER JOIN
              										users
              										ON
              										users.id=files.user_id
              										ORDER BY last_edit DESC
              									   ");
              			$stmt->execute();
              			$files=$stmt->fetchAll();

              			foreach ($files as $file):
              			echo '<tr>';
              			echo    '<th><img src="'.$img.'default_types/'.$file['extension'].'.png"class="small-img"></th>';
              			echo	'<th>';
              			echo (strlen($file['name'])>15)?str_split($file['name'],9)['0'].'...'.$file['extension']:$file['name'];
              			echo 	'</th>';
              			echo	'<th>';
              			if ($file['size']>=1073741824){
              				echo intval($file['size']/1073741824);
              				echo ' GB';
              			}elseif ($file['size']>=1048576) {
              				echo intval($file['size']/1048576);
              				echo ' MB';
              			}elseif ($file['size']>=1024) {
              				echo intval($file['size']/1024);
              				echo ' kB';
              			}else{
              				echo $file['size'];
              				echo ' B';
              			}
              			echo 	'</th>';
              			echo	'<th><span class="badge badge-default">'.$file['category_name'].'</span></th>';
              			echo	'<th><span class="';
              			echo 	($file['grade']==1)? 'badge badge-success' : 'badge';
              			echo   	'">'.$file['username'].'</span></th>';
              			echo	'<th>'.$file['last_edit'].'</th>';
              			echo	'<th><span class="';
              			echo 	($file['downloads']>10)?'badge badge-success':'badge ' ;
              			echo 	'"">'.$file['downloads'].'</span></th>';
              			echo 	'<th><div class="btn-group">';
              			echo 	'<a href="?do=perview&id='.$file['id'].'" class="btn btn-info"><span class="glyphicon glyphicon-new-window"></span></a>';
              			echo 	'<a href="?do=edit&id='.$file['id'].'" class="btn">edit</a>';
              			echo 	'<a href="?do=delete&id='.$file['id'].'" class="btn btn-danger">delete</a>';
              			echo 	'</div></th>';
              			echo '</tr>';
              			endforeach ?>

              		</table>
		        <div class="col-md-5 upload">
		        	<form action="core/base/upload.php" method="post" enctype="multipart/form-data">
					<div class="input-group">
                      <input type="file" class="form-control" name="file">
                      <div class="input-group-btn">
                      	<input type="submit" name="upload" class="btn btn-primary" tabindex="1">
                      </div>
                    </div>
					</form>
		        </div>
              </div>

            </div>

		</div>
	</div>
	<?php

}elseif ($do=='perview') {
	$title='perview file';
	require 'config.php';
	if (!checkExist('files',$_GET['id'])) {
		?>

		<div class="container pull-right users-page " style="width: 78%">
		<div class="big-red">
			<div class="alert alert-danger alert-dismissable alrt">
                 <h4>Oops!</h4> sounds like the requested file doesn't exist anymore.
                 <br><a class="btn btn-danger " href="files.php">Go back</a>
        	</div>			
		</div>

		<?php
	}else{
	              			$stmt=$db->prepare("SELECT files.*,
	              										categories.name AS category_name,
	              										users.username AS username,
	              										users.group_id AS grade
	              										FROM files
	              										INNER JOIN
	              										categories
	              										ON
	              										categories.id=files.cat_id
	              										INNER JOIN
	              										users
	              										ON
	              										users.id=files.user_id
	              										WHERE `files`.`id`=?
	              									   ");
	              			$stmt->execute(array($_GET['id']));
	              			$file=$stmt->fetch();
				?>
	
			<div class="container pull-right users-page " style="width: 78%">
	
	
			<div class="col-md-12">
				<div class="file text-left">
					<div class="file-header">
						<div class="img-fram">
							<img  src="<?php echo $img.'default_types/'.$file['extension']; ?>.png">	
						</div>
						
						<a href="users.php?do=edit&id=<?php echo $file['user_id'] ?>">
						<div class="owner text-center">
							<?php echo $file['username'] ?>
						</div>
						</a>
						
						<div class="tree">
							<ol class="breadcrumb breadcrumb-arrow">
			                  <li><a href="files.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
			                  <li><a href="#"><i class="glyphicon glyphicon-list-alt"></i> <?php echo $file['category_name'] ?></a></li>
			                  <li class="active"><span><i class="glyphicon glyphicon-file"></i> <?php echo $file['name'] ?></span></li>
		                	</ol>
	                	</div>
	
			            <div class="btn-group option-list">
				              <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
			                  <span class="caret"></span>
			                  <span class="sr-only">Toggle Dropdown</span>
					           </button>
					             <ul class="dropdown-menu" role="menu">
					               <li><a href="files.php?do=edit&id=<?php echo $file['id']  ?>"><span class="glyphicon glyphicon-pencil"></span> Edit this file</a></li>
					               <li><a href="#"><span class="glyphicon glyphicon-eye-close"></span> Hide this file</a></li>
					               <li><a href="#"><span class="glyphicon glyphicon-flag"></span> Send an alert to Ali</a></li>
					               <li class="divider"></li>
					               <li><a href="file.php?do=delete&id=<?php echo $file['id'] ?>" style="color: #da4453"><span class="glyphicon glyphicon-trash"></span> Delete this file</a></li>
					               <?php if ($file['grade']!=1): ?>
					               <li><a href="<?php echo 'users.php?do=block&id='.$file['user_id'] ?>" style="color: #da4453"><span class="glyphicon glyphicon-remove" ></span> Block <?php echo $file['username'] ?></a></li>				               	
					               <?php endif ?>
	
					             </ul>
				        </div>
	                	<div class="date">
	                		<p><?php echo $file['add_date'] ?></p>
	                	</div>
	                	<div class="title">
	                		<h2><?php echo $file['name'] ?></h2>
	                	</div>
	                	
					</div>
					<div class=" file-info">
					<ul>
						<li><b><span class="glyphicon glyphicon-qrcode"></span> ID:</b> <?php echo $file['id'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-file"></span> name:</b> <?php echo $file['name'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-info-sign"></span> description:</b> <?php echo $file['description'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-user"></span> author:</b> <?php echo $file['username'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-bookmark"></span> category:</b> <?php echo $file['category_name'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-inbox"></span> type:</b> <?php echo $file['type'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-screenshot"></span> extension:</b> .<?php echo $file['extension'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-hdd"></span> size:</b> 
						<?php
						              			if ($file['size']>=1073741824){
	              				echo intval($file['size']/1073741824);
	              				echo ' GB';
	              			}elseif ($file['size']>=1048576) {
	              				echo intval($file['size']/1048576);
	              				echo ' MB';
	              			}elseif ($file['size']>=1024) {
	              				echo intval($file['size']/1024);
	              				echo ' kB';
	              			}else{
	              				echo $file['size'];
	              				echo ' B';
	              			}
						?>
						<br></li>
						<li><b><span class="glyphicon glyphicon-calendar"></span> add date:</b> <?php echo $file['add_date'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-time"></span> last edit:</b> <?php echo $file['last_edit'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-pushpin"></span> location:</b> <?php echo $file['destination'] ?> <br></li>
						<li><b><span class="glyphicon glyphicon-download" ></span> downloads:</b> <?php echo $file['downloads'] ?> <br></li>
					</ul>
					</div>
					<div class="file-footer">
					<!--
						*** this future is to show a small perview of the audio and video files
						*** and it still need more work on it




					<?php if ($file["extension"]=='mp3'): ?>
						    <audio autoplay="autoplay" loop="loop">
      							  <source src="<?php echo 'core/base/'.$file['destination'] ?>" type='audio/mp3' />
    						</audio>
					<?php elseif($file["extension"]=='mp4'): ?>
					    <video autoplay="autoplay">
       						 <source src="<?php echo 'core/base/'.$file['destination'] ?>" type='video/mp4' />
    					</video>
    				<?php else: ?>

    				<?php endif; ?> -->


						<div class="pull-right file-buttons">
							<a class="btn btn-primary" href="files.php?do=edit&id=<?php echo $file['id']  ?>"><span class="glyphicon glyphicon-pencil"></span> Edit</a>
							<a class="btn btn-success" href="<?php echo 'core/base/'.$file['destination'] ?>"><span class="glyphicon glyphicon-download-alt"></span> Download</a>						
						</div>
	
					</div>
				</div>
	
	
	
			</div>
		</div>
			<?php }
	
}elseif ($do=='edit') {
	$title='Edit file';
	require 'config.php';
	$option = 'WHERE id ='.$_GET["id"];
	$user = getInfo('files',$option);
 	?>
	<div class="container pull-right stng-page text-center" style="width: 78%">
	<h1>Edit file</h1>
	<form class="edit-form" action="?do=update" method="POST">
		<h3>Edit the file</h3>
		<input type="hidden" name="id" value="<?php echo $user['0']['id'] ?>">
		<div class="input-group inset-btn">
            <span class="input-group-addon">name</span>
            <input type="text" class="form-control" name="name" value="<?php echo $user['0']['name'] ?>" required>
        </div>	

		<div class="input-group inset-btn">
            <span class="input-group-addon">Description</span>
            <input type="text" class="form-control" name="description" <?php echo ($user['0']['description']=='')? 'placeholder="set a description to this file"': 'value="'.$user['0']['description'].'"' ?>   required>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">category</span>
            <select name="cat_id" class="selecter_1" >
            <?php
            $cats=getInfo('categories');
             foreach ($cats as $cat): 
            echo '<option value="'.$cat['id'].'"';
        	echo ($cat['id']==$user['0']['cat_id'])? 'selected>':'>';
			echo $cat['name']."</option>";
             endforeach ?>
			</select>
        </div>

        <div>
        	<input class="btn btn-success" type="submit" value="save">
        </div>                                          
	</form>
	</div>
	</div>
	<?php
	
}elseif ($do=='update') {
	require 'config.php';
			?>

		<div class="container pull-right users-page " style="width: 78%">

		<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST'){

		if (empty($_POST['name']) || empty($_POST['description'])) { ?>
		<div class="big-red">
			<div class="alert alert-danger alert-dismissable alrt">
                 <h4>Sorry!</h4>name and description can't be empty
                 <br><a class="btn btn-danger " href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Go back</a>
        	</div>			
		</div>
			
	<?php }else{

		$stmt=$db->prepare("UPDATE files SET name=?, description=?, cat_id=? WHERE `files`.`id` = ?");
		$stmt->execute(array($_POST['name'],$_POST['description'],$_POST['cat_id'],$_POST['id']));
		header("location:files.php?scs=1");
	} 

	}
	?>
		</div>
	</div>
	<?php	
		
}elseif ($do=='approve') {
	
}elseif ($do=='delete') {
	require 'config.php';
	if ($_SERVER['REQUEST_METHOD']=='GET') {
		$stmt=$db->prepare("SELECT * FROM `files` WHERE `files`.`id` = ?");
		$stmt->execute(array($_GET['id']));	
		$file=$stmt->fetch();
		if (file_exists('core/base/'.$file['destination']) && is_writable('core/base/'.$file['destination'])) {
		unlink('core/base/'.$file['destination']);
		$stmt=$db->prepare("DELETE FROM `files` WHERE `files`.`id` = ?");
		$stmt->execute(array($_GET['id']));
		header("location:files.php?scs=1");				
		}else
		die('error');
	
	}
	
}



}
require $tmp.'footer.php';
?>