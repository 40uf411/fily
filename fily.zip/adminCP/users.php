<?php
session_start();

if(!isset($_SESSION['admin_username'])){
	$title='login';
	$nonav='';
	require 'config.php';
	require $base.'login.php';

}else{
	$do=(isset($_GET['do']) && in_array($_GET['do'], array('manage','edit','update','add','insert','delete','approve','block')))?$_GET['do']:'manage';
	

if($do=='manage'){
	$title='users';
	require 'config.php';
	?>
		<div class="container pull-right users-page " style="width: 78%">
		<h1 class="text-center">manage users</h1>
			<div class="panel panel-primary">

              <div class="panel-heading">
              All the users
              </div>
              <?php if(isset($_GET['scs']) && $_GET['scs']==1){ ?>
            <div class="alert alert-success alert-dismissable big-green">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <strong>Done!</strong> All the changes have been saved successfuly.
            </div>
            <?php } ?>
              <div class="panel-body">

              		<table class="table table-responsive">
              			<tr>
              				<th>#ID</th>
              				<th>Username</th>
              				<th>Full name</th>
              				<th>Email</th>
              				<th>last seen</th>
              				<th>Grade</th>
              				<th>statu</th>
              				<th>control</th>
              			</tr>
              			<?php foreach (getInfo('users','WHERE id != 1 ORDER BY joinday DESC') as $user): 
              			echo '<tr>';
              			echo    '<th>'.$user['id'].'</th>';
              			echo	'<th>'.$user['username'].'</th>';
              			echo	'<th>'.$user['fullName'].'</th>';
              			echo	'<th>'.$user['email'].'</th>';
              			echo	'<th>'.$user['lastseen'].'</th>';

              			echo	'<th>';
              			if($user['group_id']==0){
              			echo '<span class="badge ">Member</span>';
              			}else{
              			echo '<span class="badge badge-success">Admin</span>';}
              			echo '</th>';

              			echo	'<th>';
              			if($user['active']==0){
              			echo '<span class="badge badge-danger">Stopped</span>';
              			}elseif($user['active']==1){
              			echo '<span class="badge badge-success">Active</span>';
              			}else{echo '<span class="badge badge-warning">offline</span>';
              			}
              			echo '</th>';

              			echo '<th><div class="btn-group">';
              			echo '<a href="?do=edit&id='.$user['id'].'" class="btn">edit</a>';
              			echo '<a href="?do=delete&id='.$user['id'].'" class="btn btn-danger">delete</a>';
              			if($user['regstatus']==0){echo '<a href="?do=approve&id='.$user['id'].'" class="btn btn-success">approve</a>' ;}
              			echo '</div></th>';
              			echo '</tr>';
              			endforeach ?>

              		</table>
		        <div>
		        	<a class="btn btn-primary add-btn" type="submit" value="save" href="users.php?do=add">Add new user</a>
		        </div>
              </div>

            </div>

		</div>
	</div>
	<?php
}elseif ($do=='edit') {
	$title='Edit user';
	require 'config.php';
	$option = 'WHERE id ='.$_GET["id"];
	$user = getInfo('users',$option);
 	?>
	<div class="container pull-right stng-page text-center" style="width: 78%">
	<h1>Edit user</h1>
	<form class="edit-form" action="?do=update" method="POST">
		<h3>Edit <?php echo $user['0']['username'] ?>'s profile</h3>
		<input type="hidden" name="id" value="<?php echo $user['0']['id'] ?>">
		<div class="input-group inset-btn">
            <span class="input-group-addon">Username</span>
            <input type="text" class="form-control" name="username" placeholder="set a username" value="<?php echo $user['0']['username'] ?>" required>
        </div>	
		<div class="input-group inset-btn">
            <span class="input-group-addon">Bio</span>
            <input type="text" class="form-control" name="bio" <?php echo($user['0']['bio']!='')? 'value="'.$user['0']['bio'].'" placeholder="set a bio"':'placeholder="no bio to show you can set new one"';  ?>  >
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Email</span>
            <input type="text" class="form-control" name="email" placeholder="set an email" value="<?php echo $user['0']['email'] ?>" required>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">New password</span>
            <input type="hidden" value="<?php echo $user['0']['password'] ?>" name="oldpass">
            <input type="text" class="form-control" name="password" placeholder="set new password">
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Full name</span>
            <input type="text" class="form-control" name="fullName" value="<?php echo $user['0']['fullName'] ?>" required>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Birthday</span>
            <input type="date" class="form-control" name="birthday" value="<?php echo $user['0']['birthday'] ?>">
        </div>
        <?php if($user['0']['regstatus']==0){ ?>
		<div class="input-group inset-btn">
            <span class="input-group-addon">Registration statu</span>
            <select name="regstatus" class="selecter_1" >
				<option value="1" <?php echo ($user['0']['regstatus']==1)? 'selected':''; ?> >Approved</option>
				<option value="0" <?php echo ($user['0']['regstatus']==0)? 'selected':''; ?> >waiting to be approved</option>
			</select>
        </div>
       <?php } ?>
		<div class="input-group inset-btn">
            <span class="input-group-addon">grade</span>
            <select name="group_id" class="selecter_1" >
				<option value="1" <?php echo ($user['0']['group_id']==1)? 'selected':''; ?> >Admin</option>
				<option value="0" <?php echo ($user['0']['group_id']==0)? 'selected':''; ?> >member</option>
			</select>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">active</span>
            <select name="active" class="selecter_1" >
				<?php if ($user['0']['active']!=2){ ?> <option  value="1"   selected>Active</option>    <?php  
				  }else{ ?> <option  value="2"   selected>Offline</option>    <?php }?>
				<option value="0" <?php echo ($user['0']['active']==0)? 'selected>Off':'>block'; ?> </option>
			</select>            
        </div> 

        <div>
        	<input class="btn btn-success" type="submit" value="save">
        </div>                                          
	</form>
	</div>
	</div>
	<?php
}elseif ($do=='update') {
	require 'config.php';
			?>

		<div class="container pull-right users-page " style="width: 78%">

		<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST'){
		
		$erros=array();
		
			$username=filter_var($_POST['username'],FILTER_SANITIZE_STRING);
			if(empty($username)){$erros[]='username can\'t be empty';}
			if(strlen($username)>20){$erros[]='username can\'t be be grater than 20 characters';}
			if(strlen($username)<4){$erros[]='username can\'t be be less than 4 characters';}
		

		
			$email=filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);
			if(filter_var($email,FILTER_VALIDATE_EMAIL)!=true){
				$erros[]='email not valid';
			}
		

		
			$fullName=filter_var($_POST['fullName'],FILTER_SANITIZE_STRING);
			if(empty($fullName)){$erros[]='full name  can\'t be empty';}
			if(strlen($fullName)>20){$erros[]='full name can\'t be be grater than 35 characters';}
			if(strlen($fullName)<4){$erros[]='full name can\'t be be less than 4 characters';}
		
		
			if($_POST['password']!='' && strlen($_POST['password'])<8){$erros[]='password can\'t be less than 8 characters';}

		if (!empty($erros)) { ?>
		<div class="big-red">
			<div class="alert alert-danger alert-dismissable alrt">
                 <h4>Sorry!</h4>
                 <?php foreach ($erros as $error ): 
                 	echo '*'.$error.'</br>';
                 endforeach ?>
                 <br><a class="btn btn-danger " href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Go back</a>
        	</div>			
		</div>
			
	<?php }else{

		if($_POST['password']==''){$password=$_POST['oldpass'];}else{$password=$_POST['password'];}
		$password=password_hash($password,PASSWORD_DEFAULT,['cost'=>12]);
		$rs=(isset($_POST['regstatus']))?$_POST['regstatus']:'1';
		$stmt=$db->prepare("UPDATE users SET username=?,password=?,bio=?,email=?,fullName=?,birthday=?,regstatus=?,group_id=?,active=? WHERE id=?");
		$stmt->execute(array($username,$password,$_POST['bio'],$email,$fullName,$_POST['birthday'],$rs,$_POST['group_id'],$_POST['active'],$_POST['id']));
		header("location:users.php?scs=1");
	} 

	}
	?>
		</div>
	</div>
	<?php	

}elseif ($do=='add') {
	$title='Add user';
	require 'config.php';
 	?>
	<div class="container pull-right stng-page text-center" style="width: 78%">
	<h1>Add user</h1>
	<form class="edit-form" action="?do=insert" method="POST">
		<h3>Add new user</h3>
		<div class="input-group inset-btn">
            <span class="input-group-addon">Username</span>
            <input type="text" class="form-control" name="username" placeholder="username" required>
        </div>	

		<div class="input-group inset-btn">
            <span class="input-group-addon">Email</span>
            <input type="email" class="form-control" name="email" placeholder="email" required>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">New password</span>
            <input type="text" class="form-control" name="password" placeholder="password" required>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Full name</span>
            <input type="text" class="form-control" name="fullName" placeholder="full Name" required>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Birthday</span>
            <input type="date" class="form-control" name="birthday" >
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">grade</span>
            <select name="group_id" class="selecter_1" >
				<option value="1"  >Admin</option>
				<option value="0"  selected>member</option>
			</select>
        </div>

        <div>
        	<input class="btn btn-success" type="submit" value="save">
        </div>                                          
	</form>
	</div>
	</div>
	<?php
}elseif ($do=='insert') {
	require 'config.php';
			?>

		<div class="container pull-right users-page " style="width: 78%">

		<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST'){
		
		$erros=array();
		
			$username=filter_var($_POST['username'],FILTER_SANITIZE_STRING);
			if(empty($username)){$erros[]='username can\'t be empty';}
			if(strlen($username)>20){$erros[]='username can\'t be be grater than 20 characters';}
			if(strlen($username)<4){$erros[]='username can\'t be be less than 4 characters';}
		

		
			$email=filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);
			if(filter_var($email,FILTER_VALIDATE_EMAIL)!=true){
				$erros[]='email not valid';
			}
		

		
			$fullName=filter_var($_POST['fullName'],FILTER_SANITIZE_STRING);
			if(empty($fullName)){$erros[]='full name  can\'t be empty';}
			if(strlen($fullName)>20){$erros[]='full name can\'t be be grater than 35 characters';}
			if(strlen($fullName)<4){$erros[]='full name can\'t be be less than 4 characters';}
		
		
			if(strlen($_POST['password'])<8){$erros[]='password can\'t be less than 8 characters';}

		if (!empty($erros)) { ?>
		<div class="big-red">
			<div class="alert alert-danger alert-dismissable alrt">
                 <h4>Sorry!</h4>
                 <?php foreach ($erros as $error ): 
                 	echo '*'.$error.'</br>';
                 endforeach ?>
                 <br><a class="btn btn-danger " href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Go back</a>
        	</div>			
		</div>
			
	<?php }else{
		$password=password_hash($_POST['password'],PASSWORD_DEFAULT,['cost'=>12]);
		;

		$stmt=$db->prepare("INSERT INTO users  (username,password,email,fullName,birthday,regstatus,group_id,active,joinday) VALUES (?,?,?,?,?,1,?,1,now()) ");
		$stmt->execute(array($username,$password,$email,$fullName,$_POST['birthday'],$_POST['group_id']));
		header("location:users.php?scs=1");
	} 

	}
	?>
		</div>
	</div>
	<?php	

}elseif ($do=='delete') {
	require 'config.php';
	if ($_SERVER['REQUEST_METHOD']=='GET') {
		$stmt=$db->prepare("DELETE FROM `users` WHERE `users`.`id` = ?");
		$stmt->execute(array($_GET['id']));
		header("location:users.php?scs=1");		
	}
	
}elseif ($do=='approve') {
	require 'config.php';
	if ($_SERVER['REQUEST_METHOD']=='GET') {
		$stmt=$db->prepare("UPDATE users SET regstatus=1 WHERE id=?");
		$stmt->execute(array($_GET['id']));
		header("location:users.php?scs=1");		
	}
}elseif ($do=='block') {
	require 'config.php';
	if ($_SERVER['REQUEST_METHOD']=='GET') {
		$stmt=$db->prepare("UPDATE users SET active=0 WHERE id=?");
		$stmt->execute(array($_GET['id']));
		header("location:users.php?scs=1");		
	}
}




}
require $tmp.'footer.php';
?>