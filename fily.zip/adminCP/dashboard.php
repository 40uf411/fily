<?php
session_start();
$title='dashboard';
if(!isset($_SESSION['admin_username'])){
	$title='login';
	$nonav='';
	require 'config.php';
	require $base.'login.php';
}else{
require 'config.php';


?>
<div class="container pull-right" style="width: 78%">
		<h1 class="text-center">Dashboard</h1>
	<div class="row text-center">

		<div class="col-md-4">
			<a href="users.php">
				<div class="stat st-users">
				total users
				<span><?php echo getCount('id','users') ?></span>
				</div>				
			</a>

		</div>

		<div class="col-md-4">
			<a href="files.php">
				<div class="stat st-files">
				total files
				<span><?php echo getCount('id','files') ?></span>
				</div>				
			</a>
		</div>

		<div class="col-md-4">
			<div class="stat st-visitors">
			visitors
			<span>369</span>
			</div>
		</div>

	</div>

	<div class="col-md-6" style="margin-top:25px;">
		<div class="col-md-12">
			<div class="panel panel-primary">
	              <div class="panel-heading p-h">
	                <h3 class="panel-title users-panel"><i class="glyphicon glyphicon-user"></i> last joined users</h3>
	              </div>
	              <div class="panel-body" style="padding: 0">
		              	<div class="last-users">
				            <ul>
					            <?php 
					            foreach (getInfo('users','ORDER BY joinday DESC LIMIT 5') as $user) {
					            echo '<li><a href="users.php?do=edit&id='.$user['username'].'">'.$user['username'].'</a>';
					            if($user['active']==0){
              					echo '<span class="badge badge-danger pull-right">Stopped</span>';
              					}elseif($user['active']==1){
              					echo '<span class="badge badge-success pull-right">Active</span>';
              					}else{echo '<span class="badge badge-warning pull-right">offline</span>';
              					}
					            echo '</li>';
					            }
					            ?>
					        </ul>	              			
		              	</div>
	              </div>
	        </div>			
		</div>

		<div class="col-md-12" style="margin-top:25px;">
			<div class="panel panel-info">
	              <div class="panel-heading p-h">
	                <h3 class="panel-title users-panel"><i class="glyphicon glyphicon-exclamation-sign"></i> last reports</h3>
	              </div>
	              <div class="panel-body">
		              	<div class="last-users">
				            <ul>
					            <?php
					            if(!empty(getInfo('reports','ORDER BY date DESC LIMIT 5'))){
						            foreach (getInfo('reports','WHERE checkStatus = 0 ORDER BY date DESC LIMIT 5') as $file) {
						            	echo '<div class="reports-panel">';
	              						echo (strlen($file['text'])>35)?str_split($file['text'],45)['0'].'...':$file['text'];
	              						echo '<a class="btn btn-info pull-right" style="top:-5px;position: relative;"><i class="glyphicon glyphicon-log-in"></i></a>';
	              						echo '</div>';
						            }					            	
					            }else{
					            	echo "<h3 class='text-center' style='color: #888;margin-bottom: 20px;'>no reports to show </h3>";
					            }

					            ?>
					        </ul>	              			
		              	</div>
	              </div>
	        </div>			
		</div>


	</div>

	<div class="col-md-6" style="margin-top:25px;">
				<div class="col-md-12">
			<div class="panel panel-success">
	              <div class="panel-heading p-h">
	                <h3 class="panel-title file-panel"><i class="glyphicon glyphicon-file"></i> Last added files</h3>
	              </div>
	              <div class="panel-body">
						<table class="table" style="margin-bottom: 0">
			                <thead>
			                  <tr>
			                    <th>#</th>
			                    <th>file name</th>
			                    <th>downloads</th>
			                    <th>control</th>
			                  </tr>
			                </thead>
			                <tbody>
				              	<?php
				              	foreach (getInfo('files','ORDER BY add_date DESC LIMIT 5') as $file){
				              		echo "<tr>";

				              		echo '<th><img src="'.$img.'default_types/'.$file['extension'].'.png"class="small-img"></th>';
				              		echo	'<th>';
              						echo (strlen($file['name'])>15)?str_split($file['name'],9)['0'].'...'.$file['extension']:$file['name'];
              						echo 	'</th>';
              						echo	'<th><span class="';
              						echo 	($file['downloads']>10)?'badge badge-success':'badge ' ;
              						echo 	'"">'.$file['downloads'].'</span></th>';
              						echo 	'<th><a href="files.php?do=perview&id='.$file['id'].'" class="btn btn-info"><span class="glyphicon glyphicon-new-window"></span></a></th>';

				              		echo "</tr>";
				              	}
				              	?>
			                </tbody>
			            </table>

				 </div>
	        </div>			
		</div>
	</div>



</div>
</div>
<?php 
}
require $tmp.'footer.php';