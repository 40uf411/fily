<?php
//   connecting to the db
require 'core/cnct.php';
//set the timezone
date_default_timezone_set('Europe/london');
// website location
$location='127.0.0.1/fily/';
@$admin=$_SESSION['admin_username'];
//   main roots
$base='core/base/';
$func='core/functions/';
$tmp ='core/templates/';
$thm ='themes/';
// setting the main theme
require $thm.'theme.php';
// setting the directions
$css = 	$thm.$tm.'css/';
$js  = 	$thm.$tm.'js/';
$img = 	$thm.$tm.'img/';
// including the header and the functions
require $func.'main.php';

if (!isset($nohad)) {
require $tmp.'header.php';
}

if (!isset($nonav)) {
require $tmp.'navbar.php';
}
