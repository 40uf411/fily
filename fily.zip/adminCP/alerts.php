<?php
session_start();

if(!isset($_SESSION['admin_username'])){
	$title='login';
	$nonav='';
	require 'config.php';
	require $base.'login.php';

}else{
	$do=(isset($_GET['do']) && in_array($_GET['do'], array('manage','insert','edit','update','delete')))?$_GET['do']:'manage';

if ($do=='manage') {
	$title='alerts';
	require 'config.php';
	?>
	<div class="container pull-right users-page " style="width: 78%">
	<h1 class="text-center">Alerts</h1>
	<hr style="">
	<div class="col-md-12 alerts" style="margin-bottom: 20px">
	<div>
		<div class="new">
		<h3>write a new alert</h3>
	<form action="?do=insert" method="POST">
		<input class="form-control" type="text" name="title" placeholder="Title" required>
		<textarea class="form-control" name="content" placeholder="you can write the reort" required></textarea>

		<input class="btn btn-default col-md-2 pull-right" type="submit" value="send" style="margin:5px;">	
		<div class=" pull-right col-md-5" style="margin:5px;margin-left:0px;padding-left: 0">
			
	            
	            <select name="destination" class="selecter_1 col-md-4" >
	            <?php
	            $users=getInfo('users','ORDER BY username');
	             foreach ($users as $user): 
	            echo '<option value="'.$user['id'].'">';
				echo $user['username']."</option>";
	             endforeach ?>
				</select>
					
		</div>
		<span class="btn pull-right send-to" style="margin:5px">Send to</span>
		
	</form>

	</div>

	<div class="old">
	<h3>old alerts</h3>
	<?php 
	$stmt=$db->prepare("SELECT alerts.*,
              			users.username AS username
              			FROM alerts
              			INNER JOIN
              			users
              			ON
              			users.id=alerts.destination
              			ORDER BY add_date DESC
              			");
    $stmt->execute();
    $alerts=$stmt->fetchAll();

	foreach ($alerts as $alert ) {
	echo '<div class="old-alert"><hr>';
	echo '<h4>'.$alert['title'].'</h4>';	
	echo '<p style="font-size:17px">'.$alert['content'].'</p><div>To: ';
	echo '<a href="users.php?do=edit&id='.$alert['destination'].'" class="btn btn-link" style="font-size: 17px">'.$alert['username'].'</a>';
	echo '<p class="date">'.$alert['add_date'].'</p></div>';
	echo '<div class="btn-group pull-right alert-btn" >';
	echo '<a href="?do=edit&id='.$alert['id'].'" class="btn btn-default"><i class="glyphicon glyphicon-pencil"></i></a>';
	echo '<a href="?do=delete&id='.$alert['id'].'" class="btn btn-default"><i class="glyphicon glyphicon-trash"></i></a>';
	echo "</div></div>";
	}


	?>
	



	</div>
	
	</div>
	
		
	</div>
	</div>
</div>
	<?php
}elseif ($do=='insert') {
	require 'config.php';
			?>

		<div class="container pull-right users-page " style="width: 78%">

		<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST'){
		$errors=array();
		if(empty($_POST['title'])){$errors[]='the title  can\'t be empty';}
		if(strlen($_POST['title'])<2){$errors[]='the title  can\'t be less than 2 characters';}
		if(strlen($_POST['title'])>20){$errors[]='the title  can\'t be more than 20 characters';}
		if(empty($_POST['content'])){$errors[]='the contant can\'t be empty';}
		if(strlen($_POST['content'])<15){$errors[]='the contant can\'t be less than 15 characters';}


		if (!empty($errors)) { ?>
		<div class="big-red">
			<div class="alert alert-danger alert-dismissable alrt">
                 <h4>Sorry!</h4>
                 <?php

                 foreach ( $errors as $errr): 
                 	echo '*'.$errr.'<br>';
                 endforeach ?>

                 <br><a class="btn btn-danger " href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Go back</a>
        	</div>			
		</div>
			
	<?php }else{
		$stmt=$db->prepare("INSERT INTO alerts (title, content, destination,add_date) VALUES (?,?,?,now())");
		$stmt->execute(array($_POST['title'],$_POST['content'],$_POST['destination']));
		header("location:alerts.php");
	} 

	}
	?>
		</div>
	</div>
	<?php	

}elseif ($do=='edit') {

}elseif ($do=='update') {
		
}elseif ($do=='delete') {
	require 'config.php';
	if ($_SERVER['REQUEST_METHOD']=='GET') {
		$stmt=$db->prepare("DELETE FROM `alerts` WHERE `alerts`.`id` = ?");
		$stmt->execute(array($_GET['id']));
		header("location:alerts.php");		
	}
	
}

}
require $tmp.'footer.php';
?>