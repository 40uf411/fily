<?php
session_start();

if(!isset($_SESSION['admin_username'])){
	$title='login';
	$nonav='';
	require 'config.php';
	require $base.'login.php';

}else{
	$do=(isset($_GET['do']) && in_array($_GET['do'], array('manage','edit','update','add','insert','delete')))?$_GET['do']:'manage';

if ($do=='manage') {
	$title='categories';
	require 'config.php';
	?>
		<div class="container pull-right users-page " style="width: 78%">
		<h1 class="text-center">manage categories</h1>
			<div class="panel panel-primary">

              <div class="panel-heading">
              All the categories
              </div>
              <?php if(isset($_GET['scs']) && $_GET['scs']==1){ ?>
            <div class="alert alert-success alert-dismissable big-green">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <strong>Done!</strong> All the changes have been saved successfuly.
            </div>
            <?php } ?>
              <div class="panel-body">

              		<table class="table table-responsive ">
              			<tr>
              				<th>#ID</th>
              				<th>Name</th>
              				<th>Description</th>
              				<th>Visibility</th>
              				<th>Allow Add</th>
              				<th>Who can Add</th>
              				<th>control</th>
              			</tr>
              			<?php foreach (getInfo('categories') as $cat):
              			echo '<tr>';
              			echo    '<th>'.$cat['id'].'</th>';
              			echo	'<th>'.$cat['name'].'</th>';
              			echo	'<th>'.$cat['description'].'</th>';
              			echo	'<th>';
              			if($cat['visibility']==0){
              			echo '<span class="badge badge-danger">hidden</span>';
              			}else{
              			echo '<span class="badge badge-success">visible</span>';}
              			echo '</th>';

              			echo	'<th>';
              			if($cat['allow_add']==0){
              			echo '<span class="badge badge-danger">Off</span>';
              			}else{
              			echo '<span class="badge badge-success">On</span>';
              			}
              			echo '</th>';

              			echo	'<th>';
              			if($cat['who_can_add']==0){
              			echo '<span class="badge badge-primary">everybody</span>';
              			}else{
              			echo '<span class="badge badge-warning">Only admins</span>';
              			}
              			echo '</th>';

              			echo '<th><div class="btn-group">';
              			echo '<a href="?do=edit&id='.$cat['id'].'" class="btn">edit</a>';
              			echo '<a href="?do=delete&id='.$cat['id'].'" class="btn btn-danger">delete</a>';
              			echo '</div></th>';
              			echo '</tr>';
              			endforeach ?>

              		</table>
		        <div>
		        	<a class="btn btn-primary add-btn" type="submit" value="save" href="categories.php?do=add">Add new categorie</a>
		        </div>
              </div>

            </div>

		</div>
	</div>
	<?php

}elseif ($do=='edit') {
	$title='Edit category';
	require 'config.php';
	$option = 'WHERE id ='.$_GET["id"];
	$user = getInfo('categories',$option);
 	?>
	<div class="container pull-right stng-page text-center" style="width: 78%">
	<h1>Edit category</h1>
	<form class="edit-form" action="?do=update" method="POST">
		<h3>Edit <?php echo $user['0']['name'] ?>'s category</h3>
		<input type="hidden" name="id" value="<?php echo $user['0']['id'] ?>">
		<div class="input-group inset-btn">
            <span class="input-group-addon">name</span>
            <input type="text" class="form-control" name="name" value="<?php echo $user['0']['name'] ?>" required>
        </div>	

		<div class="input-group inset-btn">
            <span class="input-group-addon">Description</span>
            <input type="text" class="form-control" name="description" value="<?php echo $user['0']['description'] ?>" required>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Visibility</span>
            <select name="visibility" class="selecter_1" >
				<option value="1" <?php echo ($user['0']['visibility']==1)? 'selected':''; ?> >visible</option>
				<option value="0" <?php echo ($user['0']['visibility']==0)? 'selected':''; ?> >hidden</option>
			</select>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Allow Add</span>
            <select name="allow_add" class="selecter_1" >
				<option value="1" <?php echo ($user['0']['allow_add']==1)? 'selected':''; ?> >On</option>
				<option value="0" <?php echo ($user['0']['allow_add']==0)? 'selected':''; ?> >Off</option>
			</select>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">who can add</span>
            <select name="who_can_add" class="selecter_1" >
				<option value="1" <?php echo ($user['0']['who_can_add']==1)? 'selected':''; ?> >only Admins</option>
				<option value="0" <?php echo ($user['0']['who_can_add']==0)? 'selected':''; ?> >every one</option>
			</select>
        </div>


        <div>
        	<input class="btn btn-success" type="submit" value="save">
        </div>                                          
	</form>
	</div>
	</div>
	<?php

}elseif ($do=='update') {
	require 'config.php';
			?>

		<div class="container pull-right users-page " style="width: 78%">

		<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST'){

		if (empty($_POST['name'])) { ?>
		<div class="big-red">
			<div class="alert alert-danger alert-dismissable alrt">
                 <h4>Sorry!</h4>name can't be empty
                 <br><a class="btn btn-danger " href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Go back</a>
        	</div>			
		</div>
			
	<?php }else{

		$stmt=$db->prepare("UPDATE categories SET name=?, description=?, visibility=?, allow_add=?, who_can_add=? WHERE `categories`.`id` = ?");
		$stmt->execute(array($_POST['name'],$_POST['description'],$_POST['visibility'],$_POST['allow_add'],$_POST['who_can_add'],$_POST['id']));
		header("location:categories.php?scs=1");
	} 

	}
	?>
		</div>
	</div>
	<?php	

}elseif ($do=='add') {
	$title='Add category';
	require 'config.php';
 	?>
	<div class="container pull-right stng-page text-center" style="width: 78%">
	<h1>Add categories</h1>
	<form class="edit-form" action="?do=insert" method="POST">
		<h3>Add new category</h3>
		<input type="hidden" name="id" value="<?php echo $user['0']['id'] ?>">
		<div class="input-group inset-btn">
            <span class="input-group-addon">name</span>
            <input type="text" class="form-control" name="name" placeholder="set a name" required>
        </div>	

		<div class="input-group inset-btn">
            <span class="input-group-addon">Description</span>
            <input type="text" class="form-control" name="description"  placeholder="set a description">
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Visibility</span>
            <select name="visibility" class="selecter_1" >
				<option value="1" >visible</option>
				<option value="0" >hidden</option>
			</select>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">Allow Add</span>
            <select name="allow_add" class="selecter_1" >
				<option value="1">On</option>
				<option value="0">Off</option>
			</select>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">who can add</span>
            <select name="who_can_add" class="selecter_1" >
				<option value="1">only Admins</option>
				<option value="0"selected>every one</option>
			</select>
        </div>


        <div>
        	<input class="btn btn-success" type="submit" value="save">
        </div>                                          
	</form>
	</div>
	</div>
	<?php

}elseif ($do=='insert') {
	require 'config.php';
			?>

		<div class="container pull-right users-page " style="width: 78%">

		<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST'){

		if (empty($_POST['name'])) { ?>
		<div class="big-red">
			<div class="alert alert-danger alert-dismissable alrt">
                 <h4>Sorry!</h4>name can't be empty
                 <br><a class="btn btn-danger " href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Go back</a>
        	</div>			
		</div>
			
	<?php }else{
		$stmt=$db->prepare("INSERT INTO categories (name, description, visibility, allow_add, who_can_add) VALUES (?,?,?,?,?)");
		$stmt->execute(array($_POST['name'],$_POST['description'],$_POST['visibility'],$_POST['allow_add'],$_POST['who_can_add']));
		header("location:categories.php?scs=1");
	} 

	}
	?>
		</div>
	</div>
	<?php	
	
}elseif ($do=='delete') {
	require 'config.php';
	if ($_SERVER['REQUEST_METHOD']=='GET') {
		$stmt=$db->prepare("DELETE FROM `categories` WHERE `categories`.`id` = ?");
		$stmt->execute(array($_GET['id']));
		header("location:categories.php?scs=1");		
	}
	
}
	
}
require $tmp.'footer.php';
?>