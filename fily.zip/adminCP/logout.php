<?php
session_start();
require 'config.php';
$stmt=$db->prepare("UPDATE `users` SET `active` = 2 WHERE `users`.`username` = ?");
$stmt->execute(array($_SESSION['admin_username']));
session_unset();
session_destroy();
header('location:'.$_SERVER['HTTP_REFERER']);
die();
?>