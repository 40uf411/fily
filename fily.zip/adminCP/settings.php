<?php
session_start();
$title='settings';
if(!isset($_SESSION['admin_username'])){
	$title='login';
	$nonav='';
	require 'config.php';
	require $base.'login.php';
}else{
require 'config.php';



if ($_SERVER['REQUEST_METHOD']=='POST'){
	$errors= array();
		if (isset($_POST['name'])) {
			if (empty($_POST['name'])) {$errors[]='name can\'t empty';}
			if (strlen($_POST['name'])<2) {$errors[]='name can\'t be less than two caracters';}
		}
	if (isset($_POST['band']) &&empty($_POST['band'])) {$errors[]='band can\'t empty';}
	if (isset($_POST['startdate']) && (empty($_POST['startdate']) || intval($_POST['startdate']) <1900 || intval($_POST['startdate']))>date('year')) {$errors[]='start year not valid';}
	if (empty($errors)) {
		$stmt= $db->prepare("UPDATE `ws_settings` SET `name` = ?, `band` = ?, startdate= ?, active=?, registration=? WHERE `ws_settings`.`id` = 1");
		@$stmt->execute(array($_POST['name'],$_POST['band'],$_POST['startdate'],$_POST['active'],$_POST['registration']));
	}
} 

?>
<div class="container pull-right stng-page text-center" style="width: 78%">
<h1>website settings</h1>
<form class="edit-form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
	<h3>Edit the website settings</h3>
	<?php
		if (isset($errors) && !empty($errors)) { ?>
			<div class="alert alert-danger alert-dismissable alrt">
                 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                 <h4>Sorry!</h4>
                 <?php foreach ($errors as $error ): 
                 	echo '*'.$error.'</br>';
                 endforeach ?>
        	</div>			
	<?php } 
	 $ws = getInfo('ws_settings'); ?>
		<div class="input-group inset-btn">
            <span class="input-group-addon">name</span>
            <input type="text" class="form-control" name="name" value="<?php echo $ws['0']['name'] ?>">
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">band</span>
            <input type="text" class="form-control" name="band" value="<?php echo $ws['0']['band'] ?>">
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">start year</span>
            <input type="number" class="form-control stepper-input" name="startdate" value="<?php echo $ws['0']['startdate'] ?>">
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">allow registration</span>
			<select name="registration" class="selecter_1" >
				<option value="1" <?php echo ($ws['0']['registration']==1)? 'selected':''; ?> >yes</option>
				<option value="0" <?php echo ($ws['0']['registration']==0)? 'selected':''; ?> >no</option>
			</select>
        </div>

		<div class="input-group inset-btn">
            <span class="input-group-addon">website status</span>
			<select name="active" class="selecter_1" >
				<option value="1" <?php echo ($ws['0']['active']==1)? 'selected':''; ?> >Online</option>
				<option value="0" <?php echo ($ws['0']['active']==0)? 'selected':''; ?> >on repare mode</option>
			</select>
        </div>        
        
        <div>
        	<input class="btn btn-success" type="submit" value="save">
        </div>        
</form>
</div>
</div>
<?php
}
require $tmp.'footer.php';