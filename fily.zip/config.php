<?php
session_start();
if (isset($_COOKIE['username'])) {
	$_SESSION['username']=$_COOKIE['username'];
	$_SESSION['id']=$_COOKIE['user-id'];
}
//connect to the db
$cnct= 'core/cnct.php';
require $cnct;
// setting some settings 
date_default_timezone_set('Europe/london');
$location='127.0.0.1/fily';
//definitions
$theme='theme/';
//main routs
$tmp='core/templates/';
$css=$theme.'css';
$js=$theme.'js';
$img=$theme.'img';
//include the functions
require 'core/functions/main.php';
if(!isset($nohead)) {require $tmp.'header.php';}
if(!isset($nonav)) {require $tmp.'navbar.php';}

?>