<?php

$page=(isset($_GET['page']) && in_array($_GET['page'], array('browser','home','users','perview','search','search-result','profile','file','upload','signin')))? $_GET['page'] :'browser';

if ($page=='home') {

    $nonav=$nohead='';

    require 'config.php';

    require 'core/base/home.php';

}elseif ($page=='browser') {

    require 'config.php';

    require 'core/base/all-files.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';
    
}elseif ($page=='perview') {

    require 'config.php';

    require 'core/base/file-perview.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';

}elseif ($page=='search') {

    require 'config.php';

    require 'core/base/search.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';

}elseif ($page=='search-result') {

    require 'config.php';

    require 'core/base/search-result.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';

}elseif ($page=='profile') {

    require 'config.php';

    require 'core/base/profile.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';

}elseif ($page=='file') {

    require 'config.php';

    require 'core/base/file.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';

}elseif ($page=='upload') {

    require 'config.php';

    require 'core/base/upload-file.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';

}elseif ($page=='users') {

    require 'config.php';

    require 'core/base/users.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';

}elseif ($page=='signin') {

    require 'config.php';

    require 'core/functions/signin.php';

    require 'core/templates/footer.php';

    require 'core/templates/foot.php';
    
}



?>